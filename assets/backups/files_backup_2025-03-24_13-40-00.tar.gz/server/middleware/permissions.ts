import { Request, Response, NextFunction } from "express";
import { db } from "@db";
import { userPermissions } from "@db/schema";
import { eq, and } from "drizzle-orm";

export function requirePermission(permissionType: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Admin always has all permissions
    if (req.user?.isAdmin) {
      return next();
    }

    try {
      // Check if user has the required permission
      const permission = await db.query.userPermissions.findFirst({
        where: and(
          eq(userPermissions.userId, req.user!.id),
          eq(userPermissions.permissionType, permissionType)
        ),
      });

      if (permission?.granted) {
        next();
      } else {
        res.status(403).json({ message: "Permission denied" });
      }
    } catch (error) {
      console.error('Permission check error:', error);
      res.status(500).json({ message: "Error checking permissions" });
    }
  };
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  if (!req.user?.isAdmin) {
    return res.status(403).json({ message: "Not authorized" });
  }

  next();
}

export function requireEmployee(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  // Check if user is an employee based on isEmployee flag or has an employee user group
  const isEmployeeGroup = req.user?.userGroup?.startsWith('emp_') || 
                         req.user?.userGroup === 'kyc_employee' || 
                         req.user?.userGroup === 'second_admin';

  if (!req.user?.isEmployee && !isEmployeeGroup) {
    return res.status(403).json({ message: "Not authorized" });
  }

  next();
}