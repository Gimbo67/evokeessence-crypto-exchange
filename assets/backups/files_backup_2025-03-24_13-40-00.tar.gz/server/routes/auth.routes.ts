import { Router } from 'express';
import { db } from '@db';
import { users, insertUserSchema } from '@db/schema';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';
import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import { z } from 'zod';
import { sendWelcomeEmail } from '../services/email';

const router = Router();

// Set up passport local strategy
passport.use(new LocalStrategy(async (username, password, done) => {
  try {
    console.log('Login attempt for username:', username);
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));

    if (!user) {
      console.log('User not found:', username);
      return done(null, false, { message: 'Invalid credentials' });
    }

    let isValidPassword = false;

    // Check if the stored password has the scrypt format (contains a '.')
    if (user.password.includes('.')) {
      try {
        // This is a scrypt password
        const { promisify } = require('util');
        const { scrypt } = require('crypto');
        const scryptAsync = promisify(scrypt);

        console.log('Attempting to verify with scrypt');
        const [hashedPassword, salt] = user.password.split('.');
        const keyBuffer = (await scryptAsync(password, salt, 64)) as Buffer;
        const keyHex = keyBuffer.toString('hex');
        isValidPassword = keyHex === hashedPassword;
      } catch (error) {
        console.error('Error verifying scrypt password:', error);
        isValidPassword = false;
      }
    } else {
      // This is a bcrypt password
      console.log('Attempting to verify with bcrypt');
      isValidPassword = await bcrypt.compare(password, user.password);
    }

    if (!isValidPassword) {
      console.log('Password mismatch for user:', username);
      return done(null, false, { message: 'Incorrect password.' });
    }

    console.log('User authenticated successfully:', username);
    return done(null, {
      id: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin, // Use correct field name
      isEmployee: user.isEmployee,
      userGroup: user.userGroup,
      kycStatus: user.kyc_status || 'not_started', // Fixed field name
      kyc_status: user.kyc_status || 'not_started', // Include both for compatibility
      status: user.status,
      // Include other required fields from User type
      address: user.address,
      password: user.password,
      fullName: user.fullName,
      phoneNumber: user.phoneNumber,
      countryOfResidence: user.countryOfResidence,
      gender: user.gender,
      // Convert balance to string to avoid type issues
      balance: user.balance ? user.balance.toString() : '0',
      balanceCurrency: user.balanceCurrency || 'USD'
    });
  } catch (error) {
    console.error('Login error:', error);
    return done(error);
  }
}));

// Serialize user for the session
passport.serializeUser((user: any, done) => {
  console.log('Serializing user:', user.id);
  done(null, user.id);
});

// Deserialize user from the session
passport.deserializeUser(async (id: number, done) => {
  try {
    console.log('Deserializing user:', id);
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));

    if (!user) {
      return done(null, null);
    }

    // Transform the user object to match what the application expects
    const userWithoutPassword = {
      id: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
      isEmployee: user.isEmployee,
      userGroup: user.userGroup,
      kycStatus: user.kyc_status || 'not_started', // Added for frontend compatibility
      kyc_status: user.kyc_status || 'not_started',
      status: user.status,
      // Include other required User fields
      address: user.address,
      password: user.password,
      fullName: user.fullName,
      phoneNumber: user.phoneNumber,
      countryOfResidence: user.countryOfResidence,
      gender: user.gender,
      // Balance fields
      balance: user.balance ? user.balance.toString() : '0',
      balanceCurrency: user.balanceCurrency || 'USD'
    };

    done(null, userWithoutPassword);
  } catch (error) {
    console.error('Deserialization error:', error);
    done(error, null);
  }
});

// Login route
router.post('/api/auth/login', (req, res, next) => {
  console.log('Login attempt:', { username: req.body.username });

  passport.authenticate('local', async (err: any, user: any, info: any) => {
    if (err) {
      console.error('Login error:', err);
      return next(err);
    }

    if (!user) {
      console.log('Login failed:', info.message);
      return res.status(401).json({ message: info.message || 'Invalid credentials' });
    }

    // Check if 2FA is enabled
    try {
      const dbUser = await db.query.users.findFirst({
        where: eq(users.id, user.id)
      });
      
      // Only require 2FA if the user has enabled it AND they're verified
      const twoFactorEnabled = dbUser?.twoFactorEnabled || false;
      const kycStatus = (dbUser?.kyc_status || '').toLowerCase();
      const isVerified = ['approved', 'complete', 'verified'].includes(kycStatus);
      
      console.log('Login user check:', {
        username: user.username,
        twoFactorEnabled,
        kycStatus,
        isVerified
      });
      
      // Only require 2FA for verified users who have enabled it
      if (twoFactorEnabled && isVerified) {
        console.log('Verified user has 2FA enabled, requiring verification code:', user.username);
        return res.json({
          requireTwoFactor: true,
          username: user.username,
          message: 'Two-factor authentication required'
        });
      }
      
      // If 2FA is not enabled, proceed with normal login
      // Update lastLoginAt timestamp
      await db.update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, user.id));
      
      console.log('Updated lastLoginAt timestamp for user:', user.username);
      
      req.logIn(user, (loginErr) => {
        if (loginErr) {
          console.error('Login error:', loginErr);
          return next(loginErr);
        }

        console.log('Login successful for user:', user.username);
        return res.json({
          id: user.id,
          username: user.username,
          email: user.email,
          isAdmin: user.isAdmin,
          isEmployee: user.isEmployee,
          userGroup: user.userGroup,
          kycStatus: user.kyc_status || 'not_started', // For frontend compatibility
          kyc_status: user.kyc_status || 'not_started',
          balance: user.balance ? parseFloat(user.balance.toString()) : 0,
          balanceCurrency: user.balanceCurrency || 'USD',
          balances: [{
            amount: user.balance ? parseFloat(user.balance.toString()) : 0,
            currency: user.balanceCurrency || 'USD'
          }],
          twoFactorEnabled: twoFactorEnabled
        });
      });
    } catch (error) {
      console.error('Error checking 2FA status:', error);
      return res.status(500).json({ message: 'Error during login' });
    }
  })(req, res, next);
});

// User Registration Route
router.post('/api/auth/register', async (req, res) => {
  try {
    console.log('Registration attempt:', { 
      username: req.body.username,
      email: req.body.email
    });

    // Define registration schema
    const registrationSchema = z.object({
      username: z.string().min(3).max(50),
      email: z.string().email(),
      password: z.string().min(6),
      fullName: z.string().min(2),
      phoneNumber: z.string().optional(),
      address: z.string().optional(),
      countryOfResidence: z.string().optional(),
      gender: z.enum(['male', 'female', 'other']).optional(),
      kyc_status: z.string().default('not_started'),
      profileUpdated: z.boolean().default(false)
    });

    // Validate input
    const validationResult = registrationSchema.safeParse(req.body);
    if (!validationResult.success) {
      console.error('Registration validation error:', validationResult.error);
      return res.status(400).json({ 
        message: 'Invalid registration data', 
        errors: validationResult.error.errors 
      });
    }

    const validatedData = validationResult.data;

    // Check if username already exists
    const existingUser = await db.query.users.findFirst({
      where: eq(users.username, validatedData.username)
    });

    if (existingUser) {
      console.log('Registration failed: Username already exists', validatedData.username);
      return res.status(400).json({ message: 'Username already exists' });
    }

    // Check if email already exists
    const existingEmail = await db.query.users.findFirst({
      where: eq(users.email, validatedData.email)
    });

    if (existingEmail) {
      console.log('Registration failed: Email already exists', validatedData.email);
      return res.status(400).json({ message: 'Email already exists' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(validatedData.password, salt);

    // Create user in database with proper field names
    const newUser = {
      username: validatedData.username,
      email: validatedData.email,
      password: hashedPassword,
      fullName: validatedData.fullName,
      phoneNumber: validatedData.phoneNumber || '',
      address: validatedData.address || '',
      countryOfResidence: validatedData.countryOfResidence || '',
      gender: validatedData.gender || '',
      is_admin: false, // Fixed field name
      isEmployee: false,
      kyc_status: validatedData.kyc_status,
      balance: '0',
      balanceCurrency: 'USD',
      createdAt: new Date(),
      profileUpdated: validatedData.profileUpdated
    };

    console.log('Creating new user:', { username: newUser.username, email: newUser.email });
    
    const [insertedUser] = await db.insert(users).values(newUser).returning();
    
    console.log('User created successfully:', { 
      id: insertedUser.id, 
      username: insertedUser.username 
    });

    // Send welcome email with verification link
    try {
      console.log('Sending welcome email to newly registered user:', insertedUser.email);
      await sendWelcomeEmail(
        insertedUser.email || '', 
        insertedUser.fullName || insertedUser.username,
        insertedUser.id
      );
      console.log('Welcome email sent successfully');
    } catch (emailError) {
      console.error('Error sending welcome email:', emailError);
      // Don't fail registration if email fails, just log the error
    }

    // Create sanitized user object for response
    const userData = {
      id: insertedUser.id,
      username: insertedUser.username,
      email: insertedUser.email,
      fullName: insertedUser.fullName,
      address: insertedUser.address,
      countryOfResidence: insertedUser.countryOfResidence,
      phoneNumber: insertedUser.phoneNumber,
      gender: insertedUser.gender,
      isAdmin: false,
      isEmployee: false,
      kycStatus: insertedUser.kyc_status,
      balance: 0,
      balanceCurrency: 'USD',
      balances: [{
        amount: 0,
        currency: 'USD'
      }]
    };

    // Log the user in
    // Create proper user object for req.login that matches passport expectations
    const loginUser = {
      id: insertedUser.id,
      username: insertedUser.username,
      email: insertedUser.email,
      fullName: insertedUser.fullName,
      address: insertedUser.address,
      countryOfResidence: insertedUser.countryOfResidence,
      phoneNumber: insertedUser.phoneNumber,
      gender: insertedUser.gender,
      password: '', // Don't need to include actual password
      isAdmin: false,
      isEmployee: false,
      kyc_status: insertedUser.kyc_status,
      balance: '0',
      balanceCurrency: 'USD',
      status: 'active'
    };
    
    req.login(loginUser, (loginErr) => {
      if (loginErr) {
        console.error('Auto-login error after registration:', loginErr);
        // Still send successful response but note login failed
        return res.status(201).json({ 
          ...userData, 
          message: 'Registration successful but auto-login failed' 
        });
      }

      console.log('Registration and auto-login successful for user:', userData.username);
      return res.status(201).json(userData);
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Registration failed', error: (error as Error).message });
  }
});

// Session update endpoint for 2FA flow
router.post('/api/auth/session', async (req, res) => {
  console.log('Session update requested:', req.body);
  
  const { userId, twoFactorVerified } = req.body;
  
  if (!userId) {
    return res.status(400).json({ message: 'User ID is required' });
  }
  
  try {
    // Find the user in the database
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });
    
    if (!user) {
      console.error(`Session update failed: User ${userId} not found`);
      return res.status(404).json({ message: 'User not found' });
    }
    
    console.log(`Updating session for user: ${user.username} (${userId})`);
    
    // Create the user object with all required fields for the session
    const userForSession = {
      id: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
      isEmployee: user.isEmployee,
      userGroup: user.userGroup,
      kycStatus: user.kyc_status || 'not_started',
      kyc_status: user.kyc_status || 'not_started',
      status: user.status,
      address: user.address,
      fullName: user.fullName,
      phoneNumber: user.phoneNumber,
      countryOfResidence: user.countryOfResidence,
      gender: user.gender,
      balance: user.balance ? user.balance.toString() : '0',
      balanceCurrency: user.balanceCurrency || 'USD',
      twoFactorEnabled: user.twoFactorEnabled,
      twoFactorVerified: twoFactorVerified || false
    };
    
    // Log the user in using Passport's req.login
    req.login(userForSession, (loginErr) => {
      if (loginErr) {
        console.error('Error during session update login:', loginErr);
        return res.status(500).json({ message: 'Session update failed' });
      }
      
      console.log('Session updated successfully for 2FA authentication');
      return res.json({ 
        success: true, 
        message: 'Session updated successfully',
        userId: user.id,
        username: user.username
      });
    });
  } catch (error) {
    console.error('Error updating session:', error);
    return res.status(500).json({ message: 'Error updating session' });
  }
});

// Get current user route
router.get('/api/user', (req, res) => {
  if (!req.isAuthenticated()) {
    console.log('User not authenticated');
    return res.status(401).json({ message: 'Not authenticated' });
  }

  const user = req.user as any;
  console.log('Sending user data:', {
    id: user.id,
    username: user.username,
    isAdmin: user.isAdmin,
    isEmployee: user.isEmployee,
    userGroup: user.userGroup,
    balance: user.balance,
    balanceCurrency: user.balanceCurrency,
    timestamp: new Date().toISOString()
  });

  // Ensure consistent balance data format and standardize field names
  res.json({
    ...user,
    kycStatus: user.kyc_status || 'not_started', // Add for frontend compatibility
    balance: user.balance ? parseFloat(user.balance) : 0,
    balances: [{
      amount: user.balance ? parseFloat(user.balance) : 0,
      currency: user.balanceCurrency || 'USD'
    }]
  });
});

export default router;