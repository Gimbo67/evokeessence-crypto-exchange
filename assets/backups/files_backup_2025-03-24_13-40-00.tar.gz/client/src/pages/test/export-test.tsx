import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { exportUserData, deleteUser } from '@/lib/api-client';
import { generateUserDataExportPDF, generateBankStatementPDF } from '@/utils/pdf-generator';
// Import layout fixes if still needed
import { 
  fixQRCodeGeneration, 
  fixCompanyAddressPosition 
} from '@/utils/pdf-fixes';
import { useLanguage } from '@/lib/language-context';
import { Language } from '@/lib/i18n';
import { Loader2, FileText, FileSpreadsheet } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Define types for transaction data
interface Transaction {
  id: number;
  type: string;
  amount: number;
  currency: string;
  status: string;
  createdAt: string;
  reference?: string;
}

// Define types for user data
interface UserData {
  id: number;
  username: string;
  fullName?: string;
  email?: string;
  balance?: number;
  balanceCurrency?: string;
  balances?: Array<{ amount: number; currency: string }>;
  transactions?: {
    sepaDeposits?: any[];
    usdtOrders?: any[];
    usdcOrders?: any[];
  };
}

export default function ExportTestPage() {
  const [userId, setUserId] = useState('60'); // Default to test101 user
  const [isExporting, setIsExporting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isPdfExporting, setIsPdfExporting] = useState(false);
  const [isStatementExporting, setIsStatementExporting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('en');
  const { language } = useLanguage();

  const handleExport = async () => {
    setIsExporting(true);
    setError(null);
    setResult(null);
    
    try {
      console.log(`Testing export for user ID ${userId}`);
      const data = await exportUserData(userId);
      console.log('Export result:', data);
      setResult(data);
    } catch (err: any) {
      console.error('Export error:', err);
      setError(err.message || 'An unknown error occurred during export');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    setError(null);
    setResult(null);
    
    try {
      console.log(`Testing delete for user ID ${userId}`);
      const data = await deleteUser(userId);
      console.log('Delete result:', data);
      setResult(data);
    } catch (err: any) {
      console.error('Delete error:', err);
      setError(err.message || 'An unknown error occurred during delete');
    } finally {
      setIsDeleting(false);
    }
  };
  
  const handleExportPdf = async () => {
    if (!result) {
      setError('Please export the data first before generating a PDF');
      return;
    }
    
    setIsPdfExporting(true);
    
    try {
      console.log('Generating PDF from exported data with layout and QR code fixes');
      // Extract user data from API response
      const userData = result.data || result;
      
      // Create a custom translator function with selected language
      const t = (key: string) => {
        const translations: Record<string, Record<string, string>> = {
          'en': {
            'scan_to_verify': 'Scan QR to verify',
            'data_export_disclaimer': 'This document contains personal data exported in accordance with GDPR Article 15. This data is confidential and intended only for the named recipient.',
            'page': 'Page',
            'of': 'of'
          },
          'de': {
            'scan_to_verify': 'QR-Code scannen zur Überprüfung',
            'data_export_disclaimer': 'Dieses Dokument enthält persönliche Daten, die gemäß Artikel 15 der DSGVO exportiert wurden. Diese Daten sind vertraulich und nur für den genannten Empfänger bestimmt.',
            'page': 'Seite',
            'of': 'von'
          },
          'cs': {
            'scan_to_verify': 'Naskenujte QR kód pro ověření',
            'data_export_disclaimer': 'Tento dokument obsahuje osobní údaje exportované v souladu s článkem 15 GDPR. Tyto údaje jsou důvěrné a určené pouze pro jmenovaného příjemce.',
            'page': 'Strana',
            'of': 'z'
          }
        };
        
        // Return translation or key if not found
        const langDict = translations[selectedLanguage] || translations['en'];
        return langDict[key] || key;
      };
      
      try {
        // Generate PDF using the utility with our custom translator function
        // We use the regular PDF generator since it already handles QR codes properly
        await generateUserDataExportPDF(userData, t, selectedLanguage);
        console.log('User data export PDF successfully generated with improved QR code and layout');
      } catch (pdfError: any) {
        console.error('PDF generation error:', pdfError);
        setError('Error generating PDF: ' + (pdfError?.message || 'Unknown error'));
      }
      
    } catch (err: any) {
      console.error('PDF export error:', err);
      setError(err.message || 'An unknown error occurred during PDF generation');
    } finally {
      setIsPdfExporting(false);
    }
  };
  
  // Handle bank statement generation with our new enhanced async function
  const handleBankStatement = async () => {
    if (!result) {
      setError('Please export the data first before generating a bank statement');
      return;
    }
    
    setIsStatementExporting(true);
    
    try {
      console.log('Generating bank statement with enhanced formatting and translation support');
      
      // Extract user data from API response
      const userData = result.data || result;
      
      // Create transactions array from the data
      let transactions = [];
      
      if (userData.transactions) {
        // Extract transactions from different categories
        const allTransactions = [
          ...(userData.transactions.sepaDeposits || []).map((tx: any) => ({
            ...tx,
            type: 'deposit'
          })),
          ...(userData.transactions.usdtOrders || []).map((tx: any) => ({
            ...tx,
            type: 'withdrawal'
          })),
          ...(userData.transactions.usdcOrders || []).map((tx: any) => ({
            ...tx,
            type: 'withdrawal'
          }))
        ];
        
        transactions = allTransactions;
      } else {
        // If no transactions found, use minimal data for testing
        console.log('No transactions found in user data. Using minimal transaction data.');
        transactions = [
          { 
            id: 1, 
            type: 'deposit', 
            amount: 100, 
            currency: 'EUR', 
            status: 'completed', 
            createdAt: new Date().toISOString(),
            reference: 'TEST-DEPOSIT' 
          }
        ];
      }
      
      // Process user data
      const userDataFormatted = {
        id: userData.id,
        username: userData.username,
        fullName: userData.fullName || userData.username,
        email: userData.email,
        balance: userData.balance,
        balanceCurrency: userData.balanceCurrency || 'EUR',
        balances: userData.balances || [{ amount: userData.balance || 0, currency: userData.balanceCurrency || 'EUR' }]
      };
      
      // Generate the enhanced bank statement with the selected language
      // Using the fully async bank statement PDF generator
      // Define translations for bank statement
      const translations: Record<string, Record<string, string>> = {
        'en': {
          'bank_statement_title': 'Bank Statement',
          'statement_date': 'Statement Date',
          'statement_id': 'Statement ID',  
          'page': 'Page',
          'of': 'of',
          'scan_to_verify': 'Scan QR to verify'
        },
        'de': {
          'bank_statement_title': 'Kontoauszug',
          'statement_date': 'Auszugsdatum',
          'statement_id': 'Auszugsnummer',
          'page': 'Seite',
          'of': 'von',
          'scan_to_verify': 'QR-Code scannen zur Überprüfung'
        },
        'cs': {
          'bank_statement_title': 'Bankovní výpis',
          'statement_date': 'Datum výpisu',
          'statement_id': 'Číslo výpisu',
          'page': 'Strana',
          'of': 'z',
          'scan_to_verify': 'Naskenujte QR kód pro ověření'
        }
      };

      // Use the bank statement PDF generator with translations
      await generateBankStatementPDF(
        transactions,
        userDataFormatted,
        (key: string) => {
          // Create a translator function that falls back to English if not found
          const langDict = translations[selectedLanguage] || translations['en'];
          return langDict[key] || key;
        },
        selectedLanguage
      );
      
      console.log('Bank statement successfully generated with improved QR code and layout');
      
    } catch (err: any) {
      console.error('Bank statement generation error:', err);
      setError(err.message || 'An unknown error occurred during bank statement generation');
    } finally {
      setIsStatementExporting(false);
    }
  };

  return (
    <div className="container max-w-3xl mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>User Data Export/Delete Test</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Input 
                type="text" 
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="User ID"
              />
              <Button onClick={handleExport} disabled={isExporting}>
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Exporting...
                  </>
                ) : (
                  'Export Data'
                )}
              </Button>
              <Button 
                onClick={handleDelete} 
                disabled={isDeleting}
                variant="destructive"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  'Delete User'
                )}
              </Button>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-full max-w-xs">
                <label className="block text-sm font-medium mb-1">
                  Document Language
                </label>
                <Select 
                  value={selectedLanguage} 
                  onValueChange={(value) => setSelectedLanguage(value as Language)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="de">German</SelectItem>
                    <SelectItem value="cs">Czech</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 text-red-800 rounded-md">
                <h3 className="font-bold">Error</h3>
                <p>{error}</p>
              </div>
            )}

            {result && (
              <div className="p-4 bg-green-50 text-green-800 rounded-md">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold">Success</h3>
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleBankStatement} 
                      disabled={isStatementExporting}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      {isStatementExporting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Generating Statement...
                        </>
                      ) : (
                        <>
                          <FileSpreadsheet className="h-4 w-4" />
                          Bank Statement
                        </>
                      )}
                    </Button>
                    <Button 
                      onClick={handleExportPdf} 
                      disabled={isPdfExporting}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      {isPdfExporting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Generating PDF...
                        </>
                      ) : (
                        <>
                          <FileText className="h-4 w-4" />
                          User Data Export
                        </>
                      )}
                    </Button>
                  </div>
                </div>
                <pre className="mt-2 text-xs overflow-auto max-h-96">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}