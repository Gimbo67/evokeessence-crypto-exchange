import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { useUser } from "@/hooks/use-user";
import { useAuth } from "@/hooks/use-auth"; // Import useAuth from the correct file
import { useTranslations } from "@/lib/language-context";
import { InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { useQueryClient } from "@tanstack/react-query";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = loginSchema.extend({
  email: z.string().email("Invalid email address"),
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  phoneNumber: z.string().min(6, "Phone number must be at least 6 characters"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  countryOfResidence: z.string().min(2, "Country must be at least 2 characters"),
  gender: z.enum(["male", "female", "other"], {
    required_error: "Please select a gender",
  }),
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [showTwoFactor, setShowTwoFactor] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const { register, checkAuthStatus, login } = useAuth(); // Extract login function as well
  const t = useTranslations();
  const queryClient = useQueryClient();

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
  });

  const handleCodeChange = (value: string, position: number) => {
    setTwoFactorCode(prev => {
      const newCode = prev.padEnd(6, ' ').split('');
      newCode[position] = value;
      return newCode.join('').trim();
    });
  };

  async function onLogin(data: LoginFormData) {
    setIsLoading(true);
    try {
      console.log('Attempting login with:', data.username);
      const loginResult = await login(data.username, data.password);
      
      console.log('Login result:', loginResult);
      
      // Check if 2FA is required
      if (loginResult?.requireTwoFactor) {
        console.log('Two-factor authentication required');
        setShowTwoFactor(true);
        return;
      }
      
      // If login was successful, proceed with redirection
      if (loginResult?.success) {
        console.log('Login successful, proceeding with redirection');
        
        // Wait a bit for the session to be fully set up
        await new Promise(r => setTimeout(r, 200));
        
        // Get the current authenticated user to determine the proper redirect
        console.log('Fetching current user data for redirection...');
        const userInfo = await fetch('/api/user', { 
          credentials: 'include',
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        });
        
        if (userInfo.ok) {
          const userData = await userInfo.json();
          console.log('User data retrieved:', userData);
          
          await queryClient.invalidateQueries({ queryKey: ['user'] });
          
          // Redirect based on user role
          if (userData.isAdmin) {
            console.log('Redirecting to admin dashboard');
            window.location.href = '/admin/dashboard';
          } else if (userData.isEmployee) {
            console.log('Redirecting to employee dashboard');
            window.location.href = '/employee/dashboard';
          } else {
            console.log('Redirecting to user dashboard');
            // Regular user - redirect to dashboard
            setLocation("/dashboard");
          }
        } else {
          console.log('Failed to get user info, redirecting to dashboard');
          // If we can't get user info but login succeeded, just go to dashboard
          setLocation("/dashboard");
        }
      } else if (loginResult?.success === false) {
        // This should be handled by the login function already through a toast,
        // but we can add additional handling here if needed
        console.error('Login failed:', loginResult.message);
      }
    } catch (error) {
      // This should only happen for unexpected errors
      console.error('Unexpected login error in component:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function onVerifyTwoFactor() {
    setIsLoading(true);
    try {
      console.log('Starting 2FA verification during login...');
      
      // Get the username from the login form
      const username = loginForm.getValues().username;
      
      if (!username) {
        throw new Error(t('username_missing_error'));
      }
      
      // Use our improved direct API endpoint for 2FA validation
      const response = await fetch('/api/2fa/validate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-API-Request': 'true',
          'X-Requested-With': 'XMLHttpRequest',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        body: JSON.stringify({ 
          token: twoFactorCode,
          username: username,
          timestamp: new Date().getTime() // Add timestamp to prevent caching
        }),
        credentials: 'include'
      });

      console.log('2FA validation response status:', response.status);
      
      // Log response headers for debugging
      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });
      console.log('2FA validation response headers:', responseHeaders);
      
      // Check content type first to avoid Response body already used error
      const contentType = response.headers.get('Content-Type') || '';
      if (contentType.includes('text/html')) {
        // Handle HTML response before trying to parse JSON
        const htmlResponse = await response.text();
        console.error('HTML response received:', htmlResponse.substring(0, 200) + '...');
        throw new Error(t('html_response_error') || 'Unexpected HTML response from server');
      }
      
      // Try to parse JSON directly - our improved endpoint should always return JSON
      let responseData;
      try {
        responseData = await response.json();
        console.log('2FA validation response data:', responseData);
      } catch (jsonError) {
        console.error('Failed to parse JSON response:', jsonError);
        // Rethrow as a general error
        throw new Error(t('invalid_response_format') || 'Invalid response format');
      }

      // Check if request was successful
      if (!response.ok || !responseData.success) {
        console.error('2FA validation failed:', responseData);
        throw new Error(responseData.message || t('invalid_verification_code'));
      }
      
      // Success - update all auth-related states
      console.log('Invalidating all auth-related queries');
      await queryClient.invalidateQueries({ queryKey: ['user'] });
      await queryClient.invalidateQueries({ queryKey: ['2fa-status'] });
      await queryClient.invalidateQueries({ queryKey: ['auth'] });
      
      toast({
        title: t('success'),
        description: t('logged_in_successfully'),
      });
      
      // Update session state on server and local auth state
      try {
        console.log('Requesting session update after 2FA verification');
        // First try to update the session on the server (ensures cookies are set properly)
        const sessionUpdate = await fetch('/api/auth/session', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-API-Request': 'true'
          },
          credentials: 'include',
          body: JSON.stringify({
            userId: responseData.userId,
            twoFactorVerified: true
          })
        });
        
        console.log('Session update response:', sessionUpdate.status);
        
        // Then update the client-side auth state
        await checkAuthStatus();
      } catch (error) {
        console.error('Error updating session after 2FA:', error);
      }
      
      // If authentication check fails, try direct navigation
      if (!responseData) {
        console.error('No response data from 2FA verification');
        toast({
          variant: "destructive",
          title: t('error'),
          description: t('verification_failed')
        });
        return;
      }
      
      // Use the direct response data from 2FA verification for routing
      console.log('Using 2FA response data for routing:', responseData);
      
      // Always route regular users with 2FA to verified dashboard regardless of admin status
      // This is the specific fix requested: 2FA users should go to verified dashboard
      console.log('Redirecting to verified dashboard after 2FA verification');
      window.location.href = '/dashboard';
    } catch (error) {
      console.error('2FA verification error:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: error instanceof Error ? error.message : t('invalid_verification_code'),
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function onRegister(data: RegisterFormData) {
    setIsLoading(true);
    try {
      console.log('Starting registration process...');
      
      const registrationData = {
        ...data,
        profileUpdated: false,
        kyc_status: 'not_started' // Set initial KYC status
      };
      
      console.log('Sending registration data to server...');
      const result = await register(registrationData);
      
      if (!result.ok) {
        console.error('Registration failed with error:', result.message);
        throw new Error(result.message);
      }

      console.log('Registration successful, response data:', result.data);
      
      toast({
        title: t('success'),
        description: "Registered successfully",
      });
      
      try {
        // After successful registration, refresh auth status
        console.log('Checking authentication status after registration...');
        const isAuthenticated = await checkAuthStatus();
        console.log('Authentication status:', isAuthenticated);
        
        await queryClient.invalidateQueries({ queryKey: ['user'] });
        
        // Get the current authenticated user after registration
        console.log('Fetching user data after registration...');
        const response = await fetch('/api/user', { 
          credentials: 'include',
          headers: {
            'Cache-Control': 'no-cache', 
            'Pragma': 'no-cache'
          }
        });
        
        if (response.ok) {
          const userData = await response.json();
          console.log('User data retrieved:', userData);
          
          // Explicitly check role and redirect accordingly
          if (userData?.isAdmin) {
            console.log('User is admin, redirecting to admin dashboard');
            window.location.href = '/admin/dashboard';
            return;
          } else if (userData?.isEmployee) {
            console.log('User is employee, redirecting to employee dashboard');
            window.location.href = '/employee/dashboard';
            return;
          } else {
            console.log('User is regular client, redirecting to dashboard');
            // Short delay to ensure all state is updated
            setTimeout(() => {
              setLocation("/dashboard");
            }, 100);
          }
        } else {
          console.error('Failed to fetch user data after registration');
          // Fall back to default redirection
          console.log('Falling back to default dashboard redirection');
          setTimeout(() => {
            setLocation("/dashboard");
          }, 100);
        }
      } catch (authError) {
        console.error('Error during post-registration process:', authError);
        // Even if we have issues with the redirect, navigate to dashboard
        console.log('Redirecting to dashboard despite errors');
        setTimeout(() => {
          setLocation("/dashboard");
        }, 100);
      }
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        variant: "destructive",
        title: t('error'),
        description: error instanceof Error ? error.message : "Registration failed",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center bg-muted/30 px-4">
        <Card className="w-full max-w-md">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">{t('login')}</TabsTrigger>
              <TabsTrigger value="register">{t('register')}</TabsTrigger>
            </TabsList>
            <CardContent className="pt-6">
              <TabsContent value="login">
                {showTwoFactor ? (
                  <div className="space-y-4">
                    <h2 className="text-lg font-medium">{t('enter_2fa_code')}</h2>
                    <p className="text-sm text-muted-foreground">
                      {t('2fa_code_required')}
                    </p>
                    <div className="flex justify-center">
                      <div className="flex gap-2">
                        {Array.from({ length: 6 }).map((_, index) => (
                          <InputOTPSlot 
                            key={index} 
                            index={index}
                            onValueChange={(value) => handleCodeChange(value, index)}
                          >
                            {twoFactorCode[index] || ""}
                          </InputOTPSlot>
                        ))}
                      </div>
                    </div>
                    <Button
                      className="w-full"
                      onClick={onVerifyTwoFactor}
                      disabled={isLoading || twoFactorCode.length !== 6 || twoFactorCode.includes(' ')}
                    >
                      {t('verify')}
                    </Button>
                  </div>
                ) : (
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('username')}</FormLabel>
                            <FormControl>
                              <Input {...field} disabled={isLoading} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('password')}</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} disabled={isLoading} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {t('login')}
                      </Button>
                      <Button
                        type="button"
                        variant="link"
                        className="w-full"
                        onClick={() => setLocation("/password-reset")}
                      >
                        {t('forgot_password')}
                      </Button>
                    </form>
                  </Form>
                )}
              </TabsContent>

              <TabsContent value="register">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('username')}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('email')}</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('password')}</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('profile_fullname')}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('profile_phone')}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('profile_address')}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="countryOfResidence"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('profile_country')}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('profile_gender')}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('profile_select_gender')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="male">{t('profile_gender_male')}</SelectItem>
                              <SelectItem value="female">{t('profile_gender_female')}</SelectItem>
                              <SelectItem value="other">{t('profile_gender_other')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="mb-4 text-sm text-muted-foreground">
                      By registering, you agree to our{' '}
                      <a href="/legal" className="text-primary hover:underline">
                        Terms and Conditions
                      </a>
                      ,{' '}
                      <a href="/legal" className="text-primary hover:underline">
                        Refund Policy
                      </a>
                      , and all other legal agreements listed on our{' '}
                      <a href="/legal" className="text-primary hover:underline">
                        Legal Page
                      </a>
                      .
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {t('register')}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </main>
      <Footer />
    </div>
  );
}