import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';

interface Balance {
  amount: number;
  currency: string;
  usdEquivalent?: number;
}

interface User {
  id: number;
  username: string;
  email?: string;
  isAdmin: boolean;
  isEmployee: boolean;
  userGroup?: string;
  kycStatus?: string;
  kyc_status?: string;
  balances?: Balance[];
  balance?: number;
  balanceCurrency?: string;
  twoFactorEnabled?: boolean;
  fullName?: string;
  phoneNumber?: string;
  address?: string;
  countryOfResidence?: string;
  gender?: string;
}

// Transform function to handle both legacy and multi-currency balance formats
const transformUserData = (data: any): User => {
  try {
    // Handle legacy single balance format
    if (typeof data.balance !== 'undefined') {
      const balance = typeof data.balance === 'string' 
        ? parseFloat(data.balance) 
        : data.balance;

      if (isNaN(balance)) {
        console.warn('Invalid balance format:', data.balance);
        return { ...data, balances: [] };
      }

      return {
        ...data,
        balances: [{
          amount: balance,
          currency: data.balanceCurrency || 'USD'
        }]
      };
    }

    // Handle multi-currency balance format
    if (Array.isArray(data.balances)) {
      return {
        ...data,
        balances: data.balances.map((balance: { amount: string | number; currency: string; usdEquivalent?: number }) => ({
          amount: typeof balance.amount === 'string' 
            ? parseFloat(balance.amount) 
            : balance.amount,
          currency: balance.currency as string,
          usdEquivalent: balance.usdEquivalent
        }))
      };
    }

    // Fallback with empty balances array
    console.warn('No balance data found:', data);
    return {
      ...data,
      balances: []
    };
  } catch (error) {
    console.error('Error transforming user data:', error);
    return {
      ...data,
      balances: []
    };
  }
};

interface AuthContextType {
  isLoading: boolean;
  isAuthenticated: boolean;
  user: User | null;
  login: (username: string, password: string) => Promise<{
    requireTwoFactor?: boolean;
    success?: boolean;
    userData?: any;
    message?: string;
  } | undefined>;
  logout: () => Promise<void>;
  checkAuthStatus: () => Promise<boolean>;
  register: (userData: any) => Promise<any>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();


  const checkAuthStatus = async (): Promise<boolean> => {
    try {
      setIsLoading(true);
      console.log('Checking auth status...');
      const response = await axios.get('/api/user', { withCredentials: true });
      if (response.status === 200 && response.data) {
        console.log('Auth status check - received user data:', response.data);
        const userData = transformUserData(response.data);
        console.log('Auth status check - transformed user data:', userData);
        setUser(userData);
        setIsAuthenticated(true);
        return true;
      }
      console.log('Auth status check - no user data or invalid response');
      setUser(null);
      setIsAuthenticated(false);
      return false;
    } catch (error) {
      console.error('Authentication check failed:', error);
      // Make sure to clear user state on error
      setUser(null);
      setIsAuthenticated(false);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const login = async (username: string, password: string) => {
    try {
      setIsLoading(true);
      console.log('Attempting login with username:', username);
      
      // Use correct endpoint matching the server route
      const response = await axios.post('/api/auth/login', { username, password }, { 
        withCredentials: true 
      });

      console.log('Login response:', response.data);
      
      if (response.status === 200) {
        await checkAuthStatus();
        
        // Check if 2FA is required
        if (response.data.requireTwoFactor) {
          console.log('Two-factor authentication required');
          return { requireTwoFactor: true };
        }
        
        toast({
          title: "Login successful",
          description: "You are now logged in",
        });
        
        // Return success with user data
        return { 
          success: true,
          userData: response.data
        };
      }
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Handle structured error responses
      const errorMessage = error.response?.data?.message || 
                          (error instanceof Error ? error.message : "Invalid credentials");
      
      toast({
        title: "Login failed",
        description: errorMessage,
        variant: "destructive"
      });
      
      return {
        success: false,
        message: errorMessage
      };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      console.log('Attempting to logout...');
      
      // Use correct endpoint matching the server route
      const response = await axios.post('/api/auth/logout', {}, { withCredentials: true });
      
      console.log('Logout response:', response.status);
      
      // Clear user state and cache regardless of server response
      setUser(null);
      setIsAuthenticated(false);
      queryClient.setQueryData(['user'], null);
      queryClient.invalidateQueries({ queryKey: ['user'] });
      
      toast({
        title: "Logout successful",
        description: "You have been logged out",
      });
      
      // Redirect to home page
      window.location.href = '/';
    } catch (error) {
      console.error('Logout error:', error);
      
      // Even if server request fails, clear client-side state
      setUser(null);
      setIsAuthenticated(false);
      queryClient.setQueryData(['user'], null);
      queryClient.invalidateQueries({ queryKey: ['user'] });
      
      toast({
        title: "Logout",
        description: "You have been logged out",
      });
      
      window.location.href = '/';
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: any) => {
    try {
      setIsLoading(true);
      
      // Ensure kyc_status is properly set
      const registrationData = {
        ...userData,
        kyc_status: userData.kyc_status || 'not_started'
      };
      
      const response = await axios.post('/api/auth/register', registrationData, {
        withCredentials: true
      });

      if (response.status === 201 || response.status === 200) {
        console.log('Registration successful:', response.data);
        
        // Automatically log the user in after registration
        await checkAuthStatus();
        
        return {
          ok: true,
          data: response.data
        };
      } else {
        return {
          ok: false,
          message: 'Registration failed'
        };
      }
    } catch (error: any) {
      console.error('Registration error:', error);
      return {
        ok: false,
        message: error.response?.data?.message || error.message || 'Registration failed'
      };
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    isLoading,
    isAuthenticated,
    user,
    login,
    logout,
    checkAuthStatus,
    register
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}