import { useTranslations } from "@/lib/language-context";
import { COMPANY_ADDRESS } from "@/lib/config";

export default function Footer() {
  const t = useTranslations();

  return (
    <footer className="border-t py-12 bg-muted/50">
      <div className="container">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <h3 className="text-lg font-semibold mb-4">EvokeEssence s.r.o</h3>
            <p className="text-sm text-muted-foreground">
              {COMPANY_ADDRESS}
            </p>
          </div>
          <div className="text-sm text-muted-foreground text-right">
            © {new Date().getFullYear()} EvokeEssence s.r.o<br />
            Licensed by FAU
          </div>
        </div>
      </div>
    </footer>
  );
}