// This file is deprecated. Import utilities from '@/lib/utils' instead.
// For example:
// import { getStatusColor } from '@/lib/utils';

// This file will be removed in a future update.
export * from '@/lib/utils';