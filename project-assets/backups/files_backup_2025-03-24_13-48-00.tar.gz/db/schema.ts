// Define user groups as a PostgreSQL enum
export const UserGroup = {
  ADMIN: 'admin',                    // Full system access
  SECOND_RANK_ADMIN: 'second_admin', // All admin features except employee management
  KYC_EMPLOYEE: 'kyc_employee',      // KYC verification specialist
  FINANCE_EMPLOYEE: 'finance_emp',    // Financial operations
  VIEWONLY_EMPLOYEE: 'view_emp',     // Read-only access
  CLIENT: 'client',                  // Regular client
} as const;

import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

// Users table definition with updated balance type and 2FA fields
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  address: text("address"),
  phoneNumber: text("phone_number"),
  countryOfResidence: text("country_of_residence"),
  gender: text("gender"),
  email: text("email"),
  emailVerified: boolean("email_verified").default(false),
  kyc_status: text("kyc_status").default('pending'),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0"),
  balanceCurrency: text("balance_currency").default("EUR"),
  isAdmin: boolean("is_admin").default(false),
  isEmployee: boolean("is_employee").default(false),
  userGroup: text("user_group").default('client'),
  commissionFee: decimal("commission_fee", { precision: 5, scale: 2 }).default("16.00"),
  profileUpdated: boolean("profile_updated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
  status: text("status").default('active'),
  // 2FA related fields
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  twoFactorSecret: text("two_factor_secret"),
  twoFactorBackupCodes: jsonb("two_factor_backup_codes"),
  twoFactorMethod: text("two_factor_method").default('authenticator')
});

// Export schemas for validation
export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);

// Export types
export type InsertUser = typeof users.$inferInsert;
export type SelectUser = typeof users.$inferSelect;

// Define permission types
export const PermissionType = {
  VIEW_CLIENT_INFO: 'view_client_info',
  EDIT_CLIENT_INFO: 'edit_client_info',
  VIEW_TRANSACTIONS: 'view_transactions',
  EDIT_TRANSACTIONS: 'edit_transactions',
  VIEW_KYC: 'view_kyc',
  EDIT_KYC: 'edit_kyc',
  VIEW_BALANCES: 'view_balances',
  EDIT_BALANCES: 'edit_balances',
  MANAGE_EMPLOYEES: 'manage_employees',
} as const;

export const userPermissions = pgTable("user_permissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  permissionType: text("permission_type").notNull(),
  granted: boolean("granted").default(false),
  grantedBy: integer("granted_by").references(() => users.id),
  grantedAt: timestamp("granted_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const kycDocuments = pgTable("kyc_documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  documentType: text("document_type").notNull(),
  documentUrl: text("document_url").notNull(),
  driveFileId: text("drive_file_id").notNull(),
  driveViewLink: text("drive_view_link").notNull(),
  fileName: text("file_name").notNull(),
  status: text("status").default('pending'),
  adminComment: text("admin_comment"),
  reviewedAt: timestamp("reviewed_at"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  metadata: jsonb("metadata")
});

export const sepaDeposits = pgTable("sepa_deposits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  reference: text("reference").notNull(),
  status: text("status").default('pending'),
  commissionFee: decimal("commission_fee", { precision: 10, scale: 2 }).notNull(), // Updated precision to match amount
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const usdtOrders = pgTable("usdt_orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amountUsd: decimal("amount_usd", { precision: 10, scale: 2 }).notNull(),
  amountUsdt: decimal("amount_usdt", { precision: 10, scale: 2 }).notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 6 }).notNull(),
  usdtAddress: text("usdt_address").notNull(),
  network: text("network").default('TRC20'),
  status: text("status").default('processing'),
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const chatHistory = pgTable("chat_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionId: text("session_id").notNull(),
  messageContent: text("message_content").notNull(),
  messageType: text("message_type").notNull(), // 'user' or 'bot'
  metadata: jsonb("metadata"), // Store additional context like clicks, page location, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const verificationCodes = pgTable("verification_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  code: text("code").notNull(),
  type: text("type").notNull(), // 'email_verification' or 'password_reset'
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usdcOrders = pgTable("usdc_orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amountUsd: decimal("amount_usd", { precision: 10, scale: 2 }).notNull(),
  amountUsdc: decimal("amount_usdc", { precision: 10, scale: 2 }).notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 6 }).notNull(),
  usdcAddress: text("usdc_address").notNull(),
  network: text("network").default('Solana'),
  status: text("status").default('processing'),
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Profile update requests table to store pending user profile changes
export const profileUpdateRequests = pgTable("profile_update_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  fullName: text("full_name"),
  email: text("email"),
  phoneNumber: text("phone_number"),
  address: text("address"),
  countryOfResidence: text("country_of_residence"),
  gender: text("gender"),
  status: text("status").default('pending').notNull(), // pending, approved, rejected
  adminComment: text("admin_comment"),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at")
});

export const usersRelations = relations(users, ({ many }) => ({
  kycDocuments: many(kycDocuments),
  sepaDeposits: many(sepaDeposits),
  usdtOrders: many(usdtOrders),
  usdcOrders: many(usdcOrders), // Add USDC orders relation
  chatHistory: many(chatHistory),
  permissions: many(userPermissions),
  verificationCodes: many(verificationCodes),
  profileUpdateRequests: many(profileUpdateRequests), // Add profile update requests relation
}));

export const kycDocumentsRelations = relations(kycDocuments, ({ one }) => ({
  user: one(users, {
    fields: [kycDocuments.userId],
    references: [users.id],
  }),
}));

export const sepaDepositsRelations = relations(sepaDeposits, ({ one }) => ({
  user: one(users, {
    fields: [sepaDeposits.userId],
    references: [users.id],
  }),
}));

export const usdtOrdersRelations = relations(usdtOrders, ({ one }) => ({
  user: one(users, {
    fields: [usdtOrders.userId],
    references: [users.id],
  }),
}));

export const chatHistoryRelations = relations(chatHistory, ({ one }) => ({
  user: one(users, {
    fields: [chatHistory.userId],
    references: [users.id],
  }),
}));

export const userPermissionsRelations = relations(userPermissions, ({ one }) => ({
  user: one(users, {
    fields: [userPermissions.userId],
    references: [users.id],
  }),
  grantedByUser: one(users, {
    fields: [userPermissions.grantedBy],
    references: [users.id],
  }),
}));

export const verificationCodesRelations = relations(verificationCodes, ({ one }) => ({
  user: one(users, {
    fields: [verificationCodes.userId],
    references: [users.id],
  }),
}));

export const usdcOrdersRelations = relations(usdcOrders, ({ one }) => ({
  user: one(users, {
    fields: [usdcOrders.userId],
    references: [users.id],
  }),
}));

export const insertKycDocumentSchema = createInsertSchema(kycDocuments);
export const selectKycDocumentSchema = createSelectSchema(kycDocuments);
export const insertSepaDepositSchema = createInsertSchema(sepaDeposits);
export const selectSepaDepositSchema = createSelectSchema(sepaDeposits);
export const insertUsdtOrderSchema = createInsertSchema(usdtOrders);
export const selectUsdtOrderSchema = createSelectSchema(usdtOrders);
export const insertChatHistorySchema = createInsertSchema(chatHistory);
export const selectChatHistorySchema = createSelectSchema(chatHistory);
export const insertUserPermissionSchema = createInsertSchema(userPermissions);
export const selectUserPermissionSchema = createSelectSchema(userPermissions);
export const insertVerificationCodeSchema = createInsertSchema(verificationCodes);
export const selectVerificationCodeSchema = createSelectSchema(verificationCodes);
export const insertUsdcOrderSchema = createInsertSchema(usdcOrders);
export const selectUsdcOrderSchema = createSelectSchema(usdcOrders);

export type InsertKycDocument = typeof kycDocuments.$inferInsert;
export type SelectKycDocument = typeof kycDocuments.$inferSelect;
export type InsertSepaDeposit = typeof sepaDeposits.$inferInsert;
export type SelectSepaDeposit = typeof sepaDeposits.$inferSelect;
export type InsertUsdtOrder = typeof usdtOrders.$inferInsert;
export type SelectUsdtOrder = typeof usdtOrders.$inferSelect;
export type InsertChatHistory = typeof chatHistory.$inferInsert;
export type SelectChatHistory = typeof chatHistory.$inferSelect;
export type InsertUserPermission = typeof userPermissions.$inferInsert;
export type SelectUserPermission = typeof userPermissions.$inferSelect;
export type InsertVerificationCode = typeof verificationCodes.$inferInsert;
export type SelectVerificationCode = typeof verificationCodes.$inferSelect;
export type InsertUsdcOrder = typeof usdcOrders.$inferInsert;
export type SelectUsdcOrder = typeof usdcOrders.$inferSelect;

// Now add profile update requests related schemas and types
export const profileUpdateRequestsRelations = relations(profileUpdateRequests, ({ one }) => ({
  user: one(users, {
    fields: [profileUpdateRequests.userId],
    references: [users.id]
  }),
  reviewer: one(users, {
    fields: [profileUpdateRequests.reviewedBy],
    references: [users.id]
  })
}));

// Create schemas for validation
export const insertProfileUpdateRequestSchema = createInsertSchema(profileUpdateRequests);
export const selectProfileUpdateRequestSchema = createSelectSchema(profileUpdateRequests);

// Export types
export type InsertProfileUpdateRequest = typeof profileUpdateRequests.$inferInsert;
export type SelectProfileUpdateRequest = typeof profileUpdateRequests.$inferSelect;