import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useTranslations } from '@/lib/language-context';
import { Loader2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface KYCDocument {
  id: number;
  type: string;
  status: string;
  fileUrl: string;
  createdAt: string;
  adminComment?: string;
}

interface Client {
  id: number;
  username: string;
  email: string;
  fullName: string;
  address?: string;
  phoneNumber?: string;
  kycStatus: 'pending' | 'approved' | 'rejected';
  kycDocuments?: KYCDocument[];
}

interface ClientDetailProps {
  id: string;
}

export default function ClientDetail({ id }: ClientDetailProps) {
  const t = useTranslations();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const clientId = parseInt(id || "0");

  const { data: client, isLoading } = useQuery<Client>({
    queryKey: [`/api/employee/clients/${clientId}`],
  });

  const updateKycStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const res = await fetch(`/api/employee/clients/${clientId}/kyc`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kycStatus: status }),
        credentials: 'include',
      });

      if (!res.ok) {
        throw new Error(t('update_kyc_failed'));
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employee/clients/${clientId}`] });
      toast({
        title: t('success'),
        description: t('kyc_status_updated_success'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('error'),
        description: error.message || t('kyc_status_update_failed'),
        variant: 'destructive',
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">{t('loading_client_data')}</span>
      </div>
    );
  }

  if (!client) {
    return (
      <div className="container py-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              {t('client_not_found')}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      {/* Client Information */}
      <Card>
        <CardHeader>
          <CardTitle>{t('client_information')}</CardTitle>
          <CardDescription>{t('client_details_description')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t('username')}</Label>
              <p className="text-sm mt-1">{client.username}</p>
            </div>
            <div>
              <Label>{t('email')}</Label>
              <p className="text-sm mt-1">{client.email}</p>
            </div>
            <div>
              <Label>{t('full_name')}</Label>
              <p className="text-sm mt-1">{client.fullName}</p>
            </div>
            <div>
              <Label>{t('phone_number')}</Label>
              <p className="text-sm mt-1">{client.phoneNumber || t('not_provided')}</p>
            </div>
            <div className="col-span-2">
              <Label>{t('address')}</Label>
              <p className="text-sm mt-1">{client.address || t('not_provided')}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KYC Status */}
      <Card>
        <CardHeader>
          <CardTitle>{t('kyc_status')}</CardTitle>
          <CardDescription>{t('kyc_status_description')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Badge
              variant={
                client.kycStatus === 'approved' ? 'default' :
                client.kycStatus === 'rejected' ? 'destructive' :
                'secondary'
              }
            >
              {t(`kyc_${client.kycStatus}`)}
            </Badge>
            <Select
              value={client.kycStatus}
              onValueChange={(value) => {
                updateKycStatusMutation.mutate(value);
              }}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={t('select_status')} />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="pending">{t('kyc_pending')}</SelectItem>
                  <SelectItem value="approved">{t('kyc_approved')}</SelectItem>
                  <SelectItem value="rejected">{t('kyc_rejected')}</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* KYC Documents */}
      <Card>
        <CardHeader>
          <CardTitle>{t('kyc_documents')}</CardTitle>
          <CardDescription>{t('kyc_documents_description')}</CardDescription>
        </CardHeader>
        <CardContent>
          {client.kycDocuments && client.kycDocuments.length > 0 ? (
            <div className="grid gap-4">
              {client.kycDocuments.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div>
                    <p className="font-medium">{t(`document_type_${doc.type}`)}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(doc.createdAt).toLocaleDateString()}
                    </p>
                    {doc.adminComment && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {t('admin_comment')}: {doc.adminComment}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => window.open(doc.fileUrl, '_blank')}
                  >
                    {t('view_document')}
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              {t('no_documents_uploaded')}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}