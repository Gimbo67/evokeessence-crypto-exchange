import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Route, Switch } from "wouter";
import { LanguageProvider } from "@/lib/language-context";
import { queryClient } from "@/lib/queryClient";
import { AuthProvider } from "@/hooks/use-auth";
import { useAuth } from "@/hooks/use-auth";
import React, { Suspense } from 'react';

// Pages
import Home from "@/pages/home";
import Team from "@/pages/team";
import Contact from "@/pages/contact";
import FAQ from "@/pages/faq";
import Legal from "@/pages/legal";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Support from "@/pages/support";
import LoadingPage from "@/pages/loading";
import EmailVerifiedPage from "@/pages/email-verified";
import PasswordReset from "@/pages/password-reset";

// Testing pages
import DepositTest from "@/pages/test/deposit-test";
import ExportTest from "@/pages/test/export-test";
import TwoFactorTest from "@/pages/test/2fa-test";
import TwoFactorBypassTest from "@/pages/test/2fa-bypass-test";

// Lazy loaded components
const AdminDashboard = React.lazy(() => import("@/pages/admin/dashboard"));
const AdminClients = React.lazy(() => import("@/pages/admin/clients"));
const AdminClientDetail = React.lazy(() => import("@/pages/admin/client/[id]"));
const AdminTransactions = React.lazy(() => import("@/pages/admin/transactions"));
const AdminAnalytics = React.lazy(() => import("@/pages/admin/analytics"));
const BackupDashboard = React.lazy(() => import("@/pages/admin/backup"));

// Employee components
const EmployeeDashboard = React.lazy(() => import("@/pages/employee-dashboard"));
const EmployeeClients = React.lazy(() => import("@/pages/employees/clients"));
const EmployeeClientDetail = React.lazy(() => import("@/pages/employees/client-detail"));
const EmployeeTransactions = React.lazy(() => import("@/pages/employees/transactions"));
const EmployeeAnalytics = React.lazy(() => import("@/pages/employees/analytics"));
const EmployeeDocuments = React.lazy(() => import("@/pages/employees/documents"));
const KYCDashboard = React.lazy(() => import("@/pages/employees/kyc-dashboard"));

// Protected Route Component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!user) {
    return <Route path="/auth" />;
  }

  return <>{children}</>;
};

// Admin Route Component
const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!user?.isAdmin) {
    return <Route path="/dashboard" />;
  }

  return <>{children}</>;
};

// Employee Route Component
const EmployeeRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!user?.isEmployee) {
    return <Route path="/dashboard" />;
  }

  return <>{children}</>;
};

function Router() {
  console.log("Initializing Router");

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Home} />
      <Route path="/team" component={Team} />
      <Route path="/contact" component={Contact} />
      <Route path="/faq" component={FAQ} />
      <Route path="/legal" component={Legal} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/support" component={Support} />
      <Route path="/verify-email" component={EmailVerifiedPage} />
      <Route path="/password-reset" component={PasswordReset} />

      {/* Protected regular user routes */}
      <Route path="/dashboard">
        {() => (
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        )}
      </Route>

      {/* Test pages */}
      <Route path="/test/deposit">
        {() => (
          <ProtectedRoute>
            <DepositTest />
          </ProtectedRoute>
        )}
      </Route>
      
      {/* 2FA test pages - publicly accessible for testing */}
      <Route path="/test/2fa" component={TwoFactorTest} />
      <Route path="/test/2fa-bypass" component={TwoFactorBypassTest} />
      <Route path="/test/export-test" component={ExportTest} />

      {/* Protected admin routes - specific routes first */}
      <Route path="/admin/clients/:id">
        {(params) => {
          console.log("Matching admin client detail route with params:", params);
          return (
            <AdminRoute>
              <Suspense fallback={<LoadingPage />}>
                <AdminClientDetail id={params.id} />
              </Suspense>
            </AdminRoute>
          );
        }}
      </Route>

      <Route path="/admin/clients">
        {() => {
          console.log("Matching admin clients list route");
          return (
            <AdminRoute>
              <Suspense fallback={<LoadingPage />}>
                <AdminClients />
              </Suspense>
            </AdminRoute>
          );
        }}
      </Route>

      <Route path="/admin/dashboard">
        {() => (
          <AdminRoute>
            <Suspense fallback={<LoadingPage />}>
              <AdminDashboard />
            </Suspense>
          </AdminRoute>
        )}
      </Route>

      <Route path="/admin">
        {() => (
          <AdminRoute>
            <Suspense fallback={<LoadingPage />}>
              <AdminDashboard />
            </Suspense>
          </AdminRoute>
        )}
      </Route>

      <Route path="/admin/transactions">
        {() => (
          <AdminRoute>
            <Suspense fallback={<LoadingPage />}>
              <AdminTransactions />
            </Suspense>
          </AdminRoute>
        )}
      </Route>
      
      <Route path="/admin/backup">
        {() => (
          <AdminRoute>
            <Suspense fallback={<LoadingPage />}>
              <BackupDashboard />
            </Suspense>
          </AdminRoute>
        )}
      </Route>

      <Route path="/admin/analytics">
        {() => (
          <AdminRoute>
            <Suspense fallback={<LoadingPage />}>
              <AdminAnalytics />
            </Suspense>
          </AdminRoute>
        )}
      </Route>

      {/* Protected employee routes */}
      <Route path="/employee/dashboard">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeDashboard />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeDashboard />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/clients/:id">
        {(params) => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeClientDetail id={params.id} />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/clients">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeClients />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/transactions">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeTransactions />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/analytics">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeAnalytics />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/documents">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <EmployeeDocuments />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      <Route path="/employee/kyc">
        {() => (
          <EmployeeRoute>
            <Suspense fallback={<LoadingPage />}>
              <KYCDashboard />
            </Suspense>
          </EmployeeRoute>
        )}
      </Route>

      {/* Catch-all route for 404 */}
      <Route>
        {() => {
          console.log("No route match - rendering 404");
          return <NotFound />;
        }}
      </Route>
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}