import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslations } from "@/lib/language-context";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import type { User } from "@/hooks/use-user";
import { Copy } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { DepositForm } from "@/components/deposits/DepositForm";
import axios from "axios";

const depositFormSchema = z.object({
  amount: z.string()
    .refine(val => !isNaN(Number(val)), "Must be a valid number")
    .refine(val => Number(val) >= 10, "Minimum deposit is €10")
    .refine(val => Number(val) <= 1000000, "Maximum deposit is €1,000,000"),
  currency: z.enum(["EUR", "USD", "GBP", "CHF", "SEK"]),
});

type DepositFormValues = z.infer<typeof depositFormSchema>;

const bankDetails = {
  name: "EvokeEssence s.r.o.",
  iban: "CZ1234567890123456789012",
  bic: "FIOBCZPPXXX",
  address: "Prague, Czech Republic",
  reference: "REF-" + Date.now()
};

interface DepositTabProps {
  user: User;
}

export default function DepositTab({ user }: DepositTabProps) {
  const t = useTranslations();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch current commission rate
  const { data: commissionData } = useQuery({
    queryKey: ['commission-rate'],
    queryFn: async () => {
      try {
        const response = await axios.get('/api/settings/commission');
        return response.data;
      } catch (error) {
        console.error('Error fetching commission rate:', error);
        // Return default rate as fallback
        return { rate: 0.16 }; // 16% default commission
      }
    },
    staleTime: 3600000, // 1 hour
  });

  const commissionRate = commissionData?.rate || 0.16; // Use API rate or fallback to 16%

  // Create deposit mutation
  const createDeposit = useMutation({
    mutationFn: async (values: DepositFormValues) => {
      try {
        const response = await fetch("/api/deposits", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(values),
          credentials: "include"
        });

        if (!response.ok) {
          throw new Error(await response.text());
        }

        return response.json();
      } catch (error) {
        // If server is not available, return mock data for testing UI
        if (!window.navigator.onLine || error instanceof TypeError) {
          return {
            id: Date.now(),
            reference: bankDetails.reference,
            amount: {
              currency: values.currency,
              original: Number(values.amount),
              commission: Number(values.amount) * commissionRate,
              final: Number(values.amount) * (1 - commissionRate)
            }
          };
        }
        throw error;
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/deposits"] });

      // Show success toast with calculated commission information
      toast({
        title: t('success'),
        description: t('deposit_created'),
      });

      // Log deposit details for debugging
      console.log('Deposit created:', {
        originalAmount: data.amount.original,
        currency: data.amount.currency,
        commission: data.amount.commission,
        finalAmount: data.amount.final,
        exchangeRate: data.exchangeRate
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('error'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string, messageKey: string) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        toast({
          description: t(`copy_${messageKey.toLowerCase()}`),
        });
      })
      .catch(() => {
        toast({
          description: t("copy_failed"),
          variant: "destructive",
        });
      });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('deposit_funds')}</CardTitle>
        <CardDescription>
          <Alert>
            <AlertDescription>
              {t('use_registered_account')}
            </AlertDescription>
          </Alert>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 border rounded-lg p-3 bg-muted/30">
          <div>
            <div className="flex justify-between items-center">
              <p className="font-medium">{t('recipient')}</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-8"
                onClick={() => copyToClipboard(bankDetails.name, "recipient")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">{bankDetails.name}</p>
          </div>

          <div>
            <div className="flex justify-between items-center">
              <p className="font-medium">IBAN</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-8"
                onClick={() => copyToClipboard(bankDetails.iban, "IBAN")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm font-mono text-muted-foreground">{bankDetails.iban}</p>
          </div>

          <div>
            <div className="flex justify-between items-center">
              <p className="font-medium">{t('bic_swift')}</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-8"
                onClick={() => copyToClipboard(bankDetails.bic, "BIC")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm font-mono text-muted-foreground">{bankDetails.bic}</p>
          </div>

          <div>
            <div className="flex justify-between items-center">
              <p className="font-medium">{t('reference')}</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-8"
                onClick={() => copyToClipboard(bankDetails.reference, "reference")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm font-mono text-muted-foreground">{bankDetails.reference}</p>
          </div>

          <div>
            <div className="flex justify-between items-center">
              <p className="font-medium">{t('address')}</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-8"
                onClick={() => copyToClipboard(bankDetails.address, "address")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">{bankDetails.address}</p>
          </div>
        </div>

        <div className="mt-6">
          <DepositForm user={user} createDeposit={createDeposit} />
        </div>

        {/* Commission info */}
        <div className="mt-4 text-sm text-muted-foreground">
          <p>{t('commission_note', { rate: (commissionRate * 100).toFixed(0) })}</p>
        </div>
      </CardContent>
    </Card>
  );
}