import { Request, Response, NextFunction } from "express";
import { UserGroup } from "../types/user-groups";

// Main admin only
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    console.log('Authentication failed - user not logged in');
    return res.status(401).json({ message: "Not authenticated" });
  }

  if (!req.user?.isAdmin) {
    console.log('Authorization failed - user is not an admin:', {
      userId: req.user?.id,
      username: req.user?.username,
      isAdmin: req.user?.isAdmin,
      userGroup: req.user?.userGroup
    });
    return res.status(403).json({ message: "Not authorized" });
  }

  console.log('Admin access granted for user:', {
    userId: req.user.id,
    username: req.user.username,
    isAdmin: req.user.isAdmin
  });
  next();
}

// Admin or second rank admin access
export function requireAdminAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    console.log('Authentication failed - user not logged in');
    return res.status(401).json({ message: "Not authenticated" });
  }

  // Check for either admin flag or second_admin userGroup
  const hasAccess = req.user?.isAdmin || req.user?.userGroup === UserGroup.SECOND_ADMIN || req.user?.userGroup === "second_admin";

  if (!hasAccess) {
    console.log('Authorization failed - user lacks admin access:', {
      userId: req.user?.id,
      username: req.user?.username,
      isAdmin: req.user?.isAdmin,
      userGroup: req.user?.userGroup,
      hasAccess
    });
    return res.status(403).json({ message: "Not authorized" });
  }

  console.log('Admin access granted for user:', {
    userId: req.user?.id,
    username: req.user?.username,
    isAdmin: req.user?.isAdmin,
    userGroup: req.user?.userGroup,
    hasAccess
  });
  next();
}

// KYC employee access
export function requireKYCAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    console.log('Authentication failed - user not logged in');
    return res.status(401).json({ message: "Not authenticated" });
  }

  const hasAccess = req.user?.isAdmin || 
                    req.user?.userGroup === UserGroup.SECOND_ADMIN || 
                    req.user?.userGroup === UserGroup.KYC_EMPLOYEE;

  if (!hasAccess) {
    console.log('Authorization failed - user lacks KYC access:', {
      userId: req.user?.id,
      userGroup: req.user?.userGroup,
      hasAccess
    });
    return res.status(403).json({ message: "Not authorized" });
  }

  console.log('KYC access granted for user:', {
    userId: req.user?.id,
    userGroup: req.user?.userGroup,
    hasAccess
  });
  next();
}

// Finance employee access
export function requireFinanceAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    console.log('Authentication failed - user not logged in');
    return res.status(401).json({ message: "Not authenticated" });
  }

  const hasAccess = req.user?.isAdmin || 
                    req.user?.userGroup === UserGroup.SECOND_ADMIN || 
                    req.user?.userGroup === UserGroup.FINANCE_EMPLOYEE;

  if (!hasAccess) {
    console.log('Authorization failed - user lacks finance access:', {
      userId: req.user?.id,
      userGroup: req.user?.userGroup,
      hasAccess
    });
    return res.status(403).json({ message: "Not authorized" });
  }

  console.log('Finance access granted for user:', {
    userId: req.user?.id,
    userGroup: req.user?.userGroup,
    hasAccess
  });
  next();
}

// View only access - allows any employee role
export function requireEmployeeAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    console.log('Authentication failed - user not logged in');
    return res.status(401).json({ message: "Not authenticated" });
  }

  const hasAccess = req.user?.isAdmin || 
                    req.user?.userGroup === UserGroup.SECOND_ADMIN || 
                    req.user?.userGroup === UserGroup.KYC_EMPLOYEE || 
                    req.user?.userGroup === UserGroup.FINANCE_EMPLOYEE || 
                    req.user?.userGroup === UserGroup.VIEWONLY_EMPLOYEE;

  if (!hasAccess) {
    console.log('Authorization failed - user lacks employee access:', {
      userId: req.user?.id,
      userGroup: req.user?.userGroup,
      hasAccess
    });
    return res.status(403).json({ message: "Not authorized" });
  }

  console.log('Employee access granted for user:', {
    userId: req.user?.id,
    userGroup: req.user?.userGroup,
    hasAccess
  });
  next();
}