import { type Request, type Response, type NextFunction } from "express";
import { UserGroup } from "../types/user-groups";

// Middleware for checking if user is any type of employee
export function requireEmployee(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  const employeeGroups = [
    UserGroup.KYC_EMPLOYEE,
    UserGroup.FINANCE_EMPLOYEE,
    UserGroup.VIEWONLY_EMPLOYEE,
    UserGroup.SECOND_ADMIN
  ];

  if (req.user?.isAdmin || req.user?.isEmployee || (req.user?.userGroup && employeeGroups.includes(req.user.userGroup as UserGroup))) {
    next();
  } else {
    return res.status(403).json({ message: "Access denied - Employee privileges required" });
  }
}

// KYC employee middleware
export function requireKycEmployee(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  if (req.user?.isAdmin || req.user?.userGroup === UserGroup.SECOND_ADMIN || req.user?.userGroup === UserGroup.KYC_EMPLOYEE) {
    next();
  } else {
    return res.status(403).json({ message: "Access denied - KYC privileges required" });
  }
}

// Finance employee middleware
export function requireFinanceEmployee(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  if (req.user?.isAdmin || req.user?.userGroup === UserGroup.SECOND_ADMIN || req.user?.userGroup === UserGroup.FINANCE_EMPLOYEE) {
    next();
  } else {
    return res.status(403).json({ message: "Access denied - Finance privileges required" });
  }
}

// Second rank admin middleware
export function requireSecondRankAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  console.log('Checking admin access for user:', {
    userId: req.user?.id,
    isAdmin: req.user?.isAdmin,
    userGroup: req.user?.userGroup
  });

  if (req.user?.isAdmin || req.user?.userGroup === UserGroup.SECOND_ADMIN) {
    console.log('Admin access granted for user:', { userId: req.user?.id, isAdmin: req.user?.isAdmin, userGroup: req.user?.userGroup });
    next();
  } else {
    console.log('Admin access denied for user:', { userId: req.user?.id, isAdmin: req.user?.isAdmin, userGroup: req.user?.userGroup });
    return res.status(403).json({ message: "Access denied - Admin privileges required" });
  }
}