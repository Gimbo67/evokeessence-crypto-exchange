export enum UserGroup {
  KYC_EMPLOYEE = 'kyc_employee',
  FINANCE_EMPLOYEE = 'finance_emp',
  VIEWONLY_EMPLOYEE = 'viewonly_employee',
  SECOND_ADMIN = 'second_admin'
}
