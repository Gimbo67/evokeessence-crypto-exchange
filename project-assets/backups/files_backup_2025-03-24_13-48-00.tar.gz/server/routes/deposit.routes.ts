import type { Express } from "express";
import { db } from "@db";
import { sepaDeposits, users } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { format } from "date-fns";
import { requireAdmin } from "../middleware/admin";
import { z } from "zod";
import axios from "axios";
import { getExchangeRates, convertCurrency } from "../services/exchange-rates";

/**
 * Currency conversion and deposit handling utility functions
 */

// Currency types
type Currency = 'EUR' | 'USD' | 'CHF' | 'GBP';

// Constants for commission
const COMMISSION_RATE = 0.16; // 16%

/**
 * Validates if a currency pair is supported
 * @param fromCurrency - Source currency
 * @param toCurrency - Target currency
 * @returns boolean - True if the currency pair is supported
 */
const validateCurrencyPair = (fromCurrency: Currency, toCurrency: Currency): boolean => {
  const supportedCurrencies: Currency[] = ['EUR', 'USD', 'CHF', 'GBP'];
  return supportedCurrencies.includes(fromCurrency) && supportedCurrencies.includes(toCurrency);
};

/**
 * Function to get user's preferred currency and balance
 * @param tx - Drizzle-ORM transaction object
 * @param userId - ID of the user
 * @returns Promise<{ balance: number; currency: Currency }> - User's balance and preferred currency
 */
const getUserCurrencyPreference = async (
  tx: any,
  userId: number
): Promise<{ balance: number; currency: Currency }> => {
  console.log('[USER_CURRENCY] Getting user currency preference for user ID:', userId);

  const [user] = await tx
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (!user) {
    throw new Error('User not found');
  }

  const balance = parseFloat(user.balance?.toString() || '0');
  const currency = (user.balanceCurrency || 'USD') as Currency;

  console.log('[USER_CURRENCY] User currency preference:', { userId, balance, currency });

  return { balance, currency };
};

/**
 * Enhanced balance update function with proper currency handling
 * using the improved exchange rates service
 * @param tx - Drizzle-ORM transaction object
 * @param userId - ID of the user
 * @param amount - Amount to add or subtract
 * @param currency - Currency of the amount
 * @param operation - 'add' or 'subtract'
 * @returns Promise<void>
 */
const updateUserBalance = async (
  tx: any,
  userId: number,
  amount: number,
  currency: Currency,
  operation: 'add' | 'subtract'
): Promise<void> => {
  try {
    console.log('[BALANCE_UPDATE] Starting balance update:', {
      userId,
      amount: `${amount} ${currency}`,
      operation,
      timestamp: new Date().toISOString()
    });

    // Get user's current balance and currency preference
    const { balance: currentBalance, currency: userCurrency } = await getUserCurrencyPreference(tx, userId);

    // Validate currencies
    if (!validateCurrencyPair(currency, userCurrency)) {
      throw new Error(`Unsupported currency pair: ${currency}/${userCurrency}`);
    }

    // Convert amount to user's preferred currency if needed
    let amountInUserCurrency = amount;

    if (currency !== userCurrency) {
      console.log(`[BALANCE_UPDATE] Converting ${amount} ${currency} to ${userCurrency} for balance update`);
      amountInUserCurrency = await convertCurrency(amount, currency, userCurrency);
    }

    // Calculate new balance
    const balanceChange = operation === 'add' ? amountInUserCurrency : -amountInUserCurrency;
    const newBalance = Number((currentBalance + balanceChange).toFixed(2));

    console.log('[BALANCE_UPDATE] Detailed calculation:', {
      userId,
      currentBalance: `${currentBalance} ${userCurrency}`,
      operation,
      amount: `${amount} ${currency}`,
      convertedAmount: `${amountInUserCurrency} ${userCurrency}`,
      balanceChange: `${balanceChange} ${userCurrency}`,
      newBalance: `${newBalance} ${userCurrency}`
    });

    // Update user's balance
    await tx
      .update(users)
      .set({
        balance: newBalance.toString(),
        balanceCurrency: userCurrency,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));

    console.log('[BALANCE_UPDATE] User balance updated successfully');

    // Log the user's updated balance for verification
    const [updatedUser] = await tx
      .select({
        id: users.id,
        balance: users.balance,
        balanceCurrency: users.balanceCurrency
      })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (updatedUser) {
      console.log('[BALANCE_UPDATE] Verification - User balance after update:', {
        userId: updatedUser.id,
        newBalance: updatedUser.balance,
        currency: updatedUser.balanceCurrency
      });
    }
  } catch (error) {
    console.error('[BALANCE_UPDATE] Error updating user balance:', error);
    throw new Error(`Failed to update user balance: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

/**
 * Function to calculate deposit amounts with commission
 * @param originalAmount - Original deposit amount
 * @param fromCurrency - Currency of the original amount
 * @param toCurrency - Target currency (defaults to USD)
 * @returns Promise<{ originalAmount: number; commissionAmount: number; amountAfterCommission: number; exchangeRate: number; convertedAmount: number; }> - Deposit details after commission calculation and currency conversion
 */
const calculateDepositAmounts = async (
  originalAmount: number,
  fromCurrency: Currency,
  toCurrency: Currency = 'USD'
): Promise<{
  originalAmount: number;
  commissionAmount: number;
  amountAfterCommission: number;
  exchangeRate: number;
  convertedAmount: number;
}> => {
  try {
    console.log(`[DEPOSIT_CALC] Calculating deposit: ${originalAmount} ${fromCurrency} to ${toCurrency}`);

    // Verify supported currencies
    if (!validateCurrencyPair(fromCurrency, toCurrency)) {
      throw new Error(`Unsupported currency pair: ${fromCurrency}/${toCurrency}`);
    }

    // Calculate commission first
    const commissionAmount = Number((originalAmount * COMMISSION_RATE).toFixed(2));
    const amountAfterCommission = Number((originalAmount - commissionAmount).toFixed(2));
    
    console.log(`[DEPOSIT_CALC] Amount after commission: ${amountAfterCommission} ${fromCurrency}`);

    // Get exchange rate from our enhanced service
    let exchangeRate = 1;
    if (fromCurrency !== toCurrency) {
      try {
        // Convert 1 unit to get the exchange rate
        exchangeRate = await convertCurrency(1, fromCurrency, toCurrency);
        console.log(`[DEPOSIT_CALC] Current exchange rate ${fromCurrency}/${toCurrency}:`, exchangeRate);
      } catch (conversionError) {
        console.error(`[DEPOSIT_CALC] Error getting exchange rate: ${conversionError}`);
        // Use fallback if exchange rate retrieval fails
        exchangeRate = 1;
        if (fromCurrency === 'EUR' && toCurrency === 'USD') exchangeRate = 1.08;
        if (fromCurrency === 'USD' && toCurrency === 'EUR') exchangeRate = 0.93;
        if (fromCurrency === 'GBP' && toCurrency === 'USD') exchangeRate = 1.27;
        if (fromCurrency === 'USD' && toCurrency === 'GBP') exchangeRate = 0.79;
        if (fromCurrency === 'CHF' && toCurrency === 'USD') exchangeRate = 1.10;
        if (fromCurrency === 'USD' && toCurrency === 'CHF') exchangeRate = 0.91;
        console.log(`[DEPOSIT_CALC] Using fallback exchange rate: ${exchangeRate}`);
      }
    }

    // Convert to target currency - apply exchange rate AFTER commission is deducted
    const convertedAmount = Number((amountAfterCommission * exchangeRate).toFixed(2));

    console.log('[DEPOSIT_CALC] Deposit calculation details:', {
      originalAmount,
      commissionRate: COMMISSION_RATE,
      commissionAmount,
      amountAfterCommission,
      exchangeRate,
      convertedAmount,
      fromCurrency,
      toCurrency
    });

    return {
      originalAmount,
      commissionAmount,
      amountAfterCommission,
      exchangeRate,
      convertedAmount
    };
  } catch (error) {
    console.error('[DEPOSIT_CALC] Error calculating deposit amounts:', error);
    throw error;
  }
};

/**
 * Validate deposit input.
 * @param amount - Amount to validate
 * @param currency - Currency to validate
 * @throws {Error} If amount or currency is invalid.
 */
const validateDepositInput = (amount: number, currency: Currency): void => {
    if (amount < 0) {
        throw new Error("Amount cannot be negative");
    }
    if (!Number.isFinite(amount)) {
        throw new Error("Invalid amount");
    }
    if (!validateCurrencyPair(currency, 'USD')) { // Assuming USD is the target currency
        throw new Error(`Unsupported currency pair: ${currency}/USD`);
    }
};

/**
 * @param {Express} app - Express application instance
 */
export function registerDepositRoutes(app: Express) {
  // Authentication middleware for protected routes
  app.use("/api/deposits/*", (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  });

  // Update the deposit list endpoint to support all currency conversions
  app.get("/api/deposits", async (req, res) => {
    try {
      const userDeposits = await db.query.sepaDeposits.findMany({
        where: eq(sepaDeposits.userId, req.user!.id),
        orderBy: desc(sepaDeposits.createdAt),
      });

      // Get user's preferred currency
      const { currency: userCurrency } = await getUserCurrencyPreference(db, req.user!.id);

      // Convert all amounts to user's preferred currency and major currencies
      const depositsWithConversions = await Promise.all(
        userDeposits.map(async (deposit) => {
          const amount = parseFloat(deposit.amount || '0');
          const currency = (deposit.currency || 'EUR') as Currency;

          // Convert to all major currencies
          const [eurAmount, usdAmount, chfAmount, gbpAmount] = await Promise.all([
            currency === 'EUR' ? amount : convertCurrency(amount, currency, 'EUR'),
            currency === 'USD' ? amount : convertCurrency(amount, currency, 'USD'),
            currency === 'CHF' ? amount : convertCurrency(amount, currency, 'CHF'),
            currency === 'GBP' ? amount : convertCurrency(amount, currency, 'GBP')
          ]);

          // Convert to user's preferred currency if different
          const userPreferredAmount = userCurrency === currency
            ? amount
            : await convertCurrency(amount, currency, userCurrency);

          return {
            ...deposit,
            originalAmount: {
              amount,
              currency
            },
            conversions: {
              eur: eurAmount,
              usd: usdAmount,
              chf: chfAmount,
              gbp: gbpAmount,
              [userCurrency.toLowerCase()]: userPreferredAmount
            },
            userCurrency: {
              amount: userPreferredAmount,
              currency: userCurrency
            }
          };
        })
      );

      res.json(depositsWithConversions);
    } catch (error) {
      console.error('[API_DEPOSITS] Error fetching deposits:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to fetch deposits",
        code: 'FETCH_ERROR'
      });
    }
  });

  // Update the client deposit creation endpoint
  app.post("/api/deposits", async (req, res) => {
    try {
      console.log('[API_DEPOSIT_CREATE] Starting deposit creation. Auth info:', { 
        isAuthenticated: req.isAuthenticated(),
        userId: req.user?.id,
        username: req.user?.username 
      });
      console.log('[API_DEPOSIT_CREATE] Request body:', req.body);

      const result = depositSchema.safeParse(req.body);
      if (!result.success) {
        console.log('[API_DEPOSIT_CREATE] Validation error:', result.error.errors);
        return res.status(400).json({
          message: result.error.errors[0].message
        });
      }

      const { amount, currency } = result.data;
      console.log(`[API_DEPOSIT_CREATE] Parsed deposit: ${amount} ${currency}`);

      if (!req.isAuthenticated() || !req.user) {
        console.log('[API_DEPOSIT_CREATE] User not authenticated');
        return res.status(401).json({
          message: "Not authenticated",
          code: 'AUTH_ERROR'
        });
      }

      await db.transaction(async (tx) => {
        // Get user's preferred currency
        const { currency: userCurrency } = await getUserCurrencyPreference(tx, req.user!.id);
        console.log(`[API_DEPOSIT_CREATE] User currency: ${userCurrency}`);

        // Calculate deposit with commission and convert to user's currency
        const depositCalc = await calculateDepositAmounts(amount, currency as Currency);
        console.log('[API_DEPOSIT_CREATE] Deposit calculation result:', depositCalc);

        const userCurrencyAmount = await convertCurrency(
          depositCalc.amountAfterCommission,
          currency as Currency,
          userCurrency
        );

        // Also calculate USD equivalent for reporting
        const usdEquivalent = await convertCurrency(
          userCurrencyAmount,
          userCurrency,
          'USD'
        );

        // Generate unique reference number
        const reference = `PAY-${req.user!.id}-${Date.now()}`;

        // IMPORTANT: We store the amount AFTER commission in the database
        // This way, when we change the status to successful, we credit the correct amount
        console.log(`[API_DEPOSIT_CREATE] Storing commission-adjusted amount in DB: ${depositCalc.amountAfterCommission} ${currency}`);

        const [deposit] = await tx
          .insert(sepaDeposits)
          .values({
            userId: req.user!.id,
            amount: depositCalc.amountAfterCommission.toString(),
            currency,
            reference,
            status: "pending",
            commissionFee: depositCalc.commissionAmount.toString(),
            createdAt: new Date(),
          })
          .returning();

        console.log('[API_DEPOSIT_CREATE] Deposit created successfully:', {
          id: deposit.id,
          userId: deposit.userId,
          amount: deposit.amount,
          currency: deposit.currency,
          commissionFee: deposit.commissionFee,
          status: deposit.status
        });

        // Return deposit details with bank information
        const bankDetails = {
          name: "EvokeEssence s.r.o",
          iban: "CZ7527000000001234567890",
          bic: "BACXCZPP",
        };

        res.json({
          reference,
          bankDetails,
          amount: {
            original: amount,
            commission: depositCalc.commissionAmount,
            final: depositCalc.amountAfterCommission,
            currency,
            userCurrency: {
              amount: userCurrencyAmount,
              currency: userCurrency
            },
            usdEquivalent
          },
          exchangeRate: depositCalc.exchangeRate
        });
      });
    } catch (error) {
      console.error('[API_DEPOSIT_CREATE] Error creating deposit:', error);
      res.status(500).json({
        message: error instanceof Error ? `Failed to create deposit: ${error.message}` : "Failed to create deposit",
        code: 'DEPOSIT_ERROR'
      });
    }
  });

  // Update the SEPA deposit update endpoint
  // This is where the admin can change a deposit status to "successful"
  app.patch("/api/admin/deposits/sepa-:id", requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    try {
      console.log(`[ADMIN_DEPOSIT] Starting deposit status update:`, {
        depositId: id,
        newStatus: status,
        timestamp: new Date().toISOString()
      });

      const depositId = parseInt(id);
      if (isNaN(depositId) || depositId <= 0) {
        return res.status(400).json({
          message: "Invalid deposit ID: Must be a positive number"
        });
      }

      if (!['pending', 'successful', 'failed'].includes(status)) {
        return res.status(400).json({
          message: "Invalid status: Must be 'pending', 'successful', or 'failed'"
        });
      }

      await db.transaction(async (tx) => {
        // Get current deposit
        const [deposit] = await tx
          .select()
          .from(sepaDeposits)
          .where(eq(sepaDeposits.id, depositId))
          .limit(1);

        if (!deposit) {
          throw new Error("Deposit not found");
        }

        const previousStatus = deposit.status;
        console.log(`[ADMIN_DEPOSIT] Current deposit status: ${previousStatus}, changing to: ${status}`);

        // Update deposit status
        await tx
          .update(sepaDeposits)
          .set({
            status,
            completedAt: status === 'successful' ? new Date() : null,
          })
          .where(eq(sepaDeposits.id, depositId));

        // Handle balance adjustment if needed
        if ((status === 'successful' && previousStatus !== 'successful') ||
            (previousStatus === 'successful' && status !== 'successful')) {

          console.log('[ADMIN_DEPOSIT] Deposit status change requires balance update:', {
            depositId,
            previousStatus,
            newStatus: status,
            originalDepositAmount: deposit.amount,
            currency: deposit.currency,
            userId: deposit.userId,
            // IMPORTANT: The amount stored in deposit.amount is ALREADY the commission-adjusted amount
            // The 16% commission was already deducted when creating the deposit record
            commissionApplied: true,
            timestamp: new Date().toISOString()
          });

          // Get the commission-adjusted amount from the deposit record
          // IMPORTANT: deposit.amount is already the amount AFTER 16% commission deduction
          const amount = parseFloat(deposit.amount || '0');
          const currency = (deposit.currency || 'EUR') as Currency;

          console.log(`[ADMIN_DEPOSIT] Using commission-adjusted amount for balance update: ${amount} ${currency}`);

          // Get user's current balance BEFORE the update for logging purposes
          const { balance: currentBalance, currency: userCurrency } = await getUserCurrencyPreference(tx, deposit.userId);
          console.log(`[ADMIN_DEPOSIT] User's current balance BEFORE update: ${currentBalance} ${userCurrency}`);

          // When changing to successful, we ADD this amount to the user's balance
          // When changing from successful to another status, we SUBTRACT it
          await updateUserBalance(
            tx,
            deposit.userId,
            amount,
            currency,
            status === 'successful' ? 'add' : 'subtract'
          );

          // Add additional logging to verify balance update
          console.log(`[ADMIN_DEPOSIT] Balance update completed for user ${deposit.userId}`);

          // Get user's updated balance for verification
          const [updatedUser] = await tx
            .select({
              id: users.id,
              balance: users.balance,
              balanceCurrency: users.balanceCurrency
            })
            .from(users)
            .where(eq(users.id, deposit.userId))
            .limit(1);

          if (updatedUser) {
            console.log(`[ADMIN_DEPOSIT] User's new balance AFTER update: ${updatedUser.balance} ${updatedUser.balanceCurrency}`);
          }
        }

        // Get updated deposit for response
        const [updatedDeposit] = await tx
          .select()
          .from(sepaDeposits)
          .where(eq(sepaDeposits.id, depositId))
          .limit(1);

        res.json(updatedDeposit);
      });
    } catch (error) {
      console.error('[ADMIN_DEPOSIT] Error updating SEPA deposit:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to update deposit status",
        code: 'UPDATE_ERROR'
      });
    }
  });

  // Delete SEPA deposit (admin only, only pending deposits)
  app.delete("/api/admin/deposits/:id", requireAdmin, async (req, res) => {
    const { id } = req.params;

    try {
      const [deposit] = await db
        .select()
        .from(sepaDeposits)
        .where(eq(sepaDeposits.id, parseInt(id)))
        .limit(1);

      if (!deposit) {
        return res.status(404).json({ message: "Deposit not found" });
      }

      if (deposit.status !== "pending") {
        return res.status(400).json({ message: "Only pending deposits can be deleted" });
      }

      await db
        .delete(sepaDeposits)
        .where(eq(sepaDeposits.id, parseInt(id)));

      res.json({ message: "Deposit deleted successfully" });
    } catch (error) {
      console.error('Error deleting deposit:', error);
      res.status(500).json({ message: "Failed to delete deposit" });
    }
  });

  // Download SEPA deposits as CSV with all currency conversions
  app.get("/api/deposits/download", async (req, res) => {
    try {
      const userDeposits = await db.query.sepaDeposits.findMany({
        where: eq(sepaDeposits.userId, req.user!.id),
        orderBy: desc(sepaDeposits.createdAt),
      });

      // Get user's preferred currency
      const { currency: userCurrency } = await getUserCurrencyPreference(db, req.user!.id);

      // Convert amounts to all supported currencies with validation
      const depositsWithConversions = await Promise.all(
        userDeposits.map(async (deposit) => {
          const amount = parseFloat(deposit.amount || '0');
          const currency = (deposit.currency || 'EUR') as Currency;

          // Convert to all major currencies using validated operations
          const [eurAmount, usdAmount, chfAmount, gbpAmount] = await Promise.all([
            currency === 'EUR' ? amount : convertCurrency(amount, currency, 'EUR'),
            currency === 'USD' ? amount : convertCurrency(amount, currency, 'USD'),
            currency === 'CHF' ? amount : convertCurrency(amount, currency, 'CHF'),
            currency === 'GBP' ? amount : convertCurrency(amount, currency, 'GBP')
          ]);

          // Convert to user's preferred currency if different
          const userPreferredAmount = userCurrency === currency
            ? amount
            : await convertCurrency(amount, currency, userCurrency);

          return {
            ...deposit,
            amountEur: eurAmount,
            amountUsd: usdAmount,
            amountChf: chfAmount,
            amountGbp: gbpAmount,
            amountUserCurrency: userPreferredAmount
          };
        })
      );

      // Generate CSV content with all currency conversions
      const csvHeader = [
        "Date",
        "Reference",
        "Original Amount",
        "Original Currency",
        "EUR Equivalent",
        "USD Equivalent",
        "CHF Equivalent",
        "GBP Equivalent",
        `${userCurrency} (Your Currency)`,
        "Status",
        "Commission Fee"
      ].join(",") + "\n";

      const csvRows = depositsWithConversions.map(deposit => {
        const date = deposit.createdAt ? format(new Date(deposit.createdAt), 'yyyy-MM-dd HH:mm:ss') : '';
        return [
          date,
          deposit.reference,
          deposit.amount,
          deposit.currency,
          deposit.amountEur.toFixed(2),
          deposit.amountUsd.toFixed(2),
          deposit.amountChf.toFixed(2),
          deposit.amountGbp.toFixed(2),
          deposit.amountUserCurrency.toFixed(2),
          deposit.status,
          deposit.commissionFee
        ].join(",");
      }).join("\n");

      const csvContent = csvHeader + csvRows;

      // Set headers for file download
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=deposit-history-${format(new Date(), 'yyyy-MM-dd')}.csv`);

      res.send(csvContent);
    } catch (error) {
      console.error('Error generating deposit history:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to generate deposit history",
        code: 'EXPORT_ERROR'
      });
    }
  });
}

// Update deposit schema with proper validation
const depositSchema = z.object({
  amount: z.string()
    .transform((val) => parseFloat(val))
    .refine((val) => !isNaN(val), "Invalid amount")
    .refine((val) => val >= 100, "Minimum deposit amount is 100")
    .refine((val) => val <= 200000, "Maximum deposit amount is 200,000"),
  currency: z.enum(['EUR', 'USD', 'CHF', 'GBP'])
});