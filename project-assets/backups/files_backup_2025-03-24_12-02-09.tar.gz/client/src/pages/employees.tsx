import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Check, X, Loader2 } from "lucide-react";

const PERMISSIONS = [
  { id: "view_client_info", label: "View Client Information" },
  { id: "edit_client_info", label: "Edit Client Information" },
  { id: "view_transactions", label: "View Transactions" },
  { id: "edit_transactions", label: "Edit Transactions" },
  { id: "view_kyc", label: "View KYC Documents" },
  { id: "edit_kyc", label: "Edit KYC Status" },
  { id: "view_balances", label: "View Client Balances" },
  { id: "edit_balances", label: "Edit Client Balances" },
  { id: "manage_employees", label: "Manage Employees" },
];

const USER_GROUPS = [
  { id: "emp_manager", label: "Employee Manager" },
  { id: "emp_kyc", label: "KYC Specialist" },
  { id: "emp_support", label: "Customer Support" },
  { id: "emp_finance", label: "Financial Operations" },
];

interface Permission {
  permissionType: string;
  granted: boolean;
}

interface Employee {
  id: number;
  username: string;
  fullName: string;
  email: string;
  userGroup: string;
  permissions: Record<string, boolean>;
}

export default function EmployeesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newEmployee, setNewEmployee] = useState({
    username: "",
    password: "",
    fullName: "",
    email: "",
    userGroup: "",
  });

  // Track loading state for each permission checkbox
  const [loadingPermissions, setLoadingPermissions] = useState<{
    [key: string]: boolean;
  }>({});

  // Query employees with permissions
  const { data: employees = [], isLoading } = useQuery<Employee[]>({
    queryKey: ["/api/admin/employees"],
  });

  // Mutation for creating employee
  const createEmployeeMutation = useMutation({
    mutationFn: async (employeeData: any) => {
      const res = await fetch("/api/admin/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(employeeData),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/employees"] });
      toast({
        title: "Success",
        description: "Employee account created successfully",
      });
      setNewEmployee({
        username: "",
        password: "",
        fullName: "",
        email: "",
        userGroup: "",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for updating permissions
  const updatePermissionsMutation = useMutation({
    mutationFn: async ({
      userId,
      permissionType,
      granted,
    }: {
      userId: number;
      permissionType: string;
      granted: boolean;
    }) => {
      const loadingKey = `${userId}-${permissionType}`;
      setLoadingPermissions(prev => ({ ...prev, [loadingKey]: true }));

      try {
        const employee = employees.find(emp => emp.id === userId);
        if (!employee) throw new Error("Employee not found");

        const updatedPermissions = {
          ...employee.permissions,
          [permissionType]: granted,
        };

        const res = await fetch(`/api/admin/employees/${userId}/permissions`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ permissions: updatedPermissions }),
          credentials: "include",
        });

        if (!res.ok) {
          throw new Error(await res.text());
        }

        return { userId, permissionType, granted };
      } finally {
        setLoadingPermissions(prev => ({ ...prev, [loadingKey]: false }));
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/employees"] });
      toast({
        title: "Success",
        description: `Permission ${data.granted ? "granted" : "revoked"} successfully`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    createEmployeeMutation.mutate({
      ...newEmployee,
      isEmployee: true,
    });
  };

  const handlePermissionChange = (
    userId: number,
    permissionType: string,
    granted: boolean
  ) => {
    updatePermissionsMutation.mutate({
      userId,
      permissionType,
      granted,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Create Employee Account</CardTitle>
          <CardDescription>
            Add a new employee with specific permissions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateEmployee} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={newEmployee.username}
                  onChange={(e) =>
                    setNewEmployee({ ...newEmployee, username: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={newEmployee.password}
                  onChange={(e) =>
                    setNewEmployee({ ...newEmployee, password: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={newEmployee.fullName}
                  onChange={(e) =>
                    setNewEmployee({ ...newEmployee, fullName: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newEmployee.email}
                  onChange={(e) =>
                    setNewEmployee({ ...newEmployee, email: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="userGroup">Role</Label>
                <Select
                  value={newEmployee.userGroup}
                  onValueChange={(value) =>
                    setNewEmployee({ ...newEmployee, userGroup: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {USER_GROUPS.map((group) => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.label}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button 
              type="submit" 
              className="w-full"
              disabled={createEmployeeMutation.isPending}
            >
              {createEmployeeMutation.isPending ? "Creating..." : "Create Employee Account"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Employee Permissions</CardTitle>
          <CardDescription>
            Manage access rights for each employee
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Role</TableHead>
                {PERMISSIONS.map((perm) => (
                  <TableHead key={perm.id} className="text-center">
                    <div className="text-xs font-medium leading-none">
                      {perm.label}
                    </div>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell className="font-medium">
                    {employee.fullName}
                  </TableCell>
                  <TableCell>{employee.userGroup}</TableCell>
                  {PERMISSIONS.map((perm) => {
                    const isLoading = loadingPermissions[`${employee.id}-${perm.id}`];
                    return (
                      <TableCell key={perm.id} className="text-center">
                        <div className="flex items-center justify-center">
                          <Checkbox
                            checked={employee.permissions?.[perm.id] || false}
                            onCheckedChange={(checked) =>
                              handlePermissionChange(employee.id, perm.id, checked as boolean)
                            }
                            disabled={isLoading}
                            className="relative"
                          />
                          {isLoading ? (
                            <Loader2 className="w-4 h-4 text-primary absolute animate-spin" />
                          ) : employee.permissions?.[perm.id] ? (
                            <Check className="w-4 h-4 text-green-500 absolute opacity-50 pointer-events-none" />
                          ) : (
                            <X className="w-4 h-4 text-red-500 absolute opacity-50 pointer-events-none" />
                          )}
                        </div>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}