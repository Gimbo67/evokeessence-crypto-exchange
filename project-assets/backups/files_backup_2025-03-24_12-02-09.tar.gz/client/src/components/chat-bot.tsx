import { useState, useEffect } from "react";

export function ChatBot() {
  return null; // Chatbot deactivated
}