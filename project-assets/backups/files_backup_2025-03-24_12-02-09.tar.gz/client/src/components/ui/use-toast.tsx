
import { useToast } from "@/hooks/use-toast"
import { toast } from "@/hooks/use-toast"

export { useToast, toast }
