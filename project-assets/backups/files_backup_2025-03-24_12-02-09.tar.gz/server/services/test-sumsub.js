// These test files are deprecated as we now use direct URL redirection
// File to be deleted

module.exports = {};