import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { type Express } from "express";
import session from "express-session";
import createMemoryStore from "memorystore";
import { randomBytes } from "crypto";
import { promisify } from "util";
import { users, insertUserSchema, type SelectUser } from "@db/schema";
import { db } from "@db";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

const MemoryStore = createMemoryStore(session);

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    return await bcrypt.compare(supplied, stored);
  } catch (error) {
    console.error('Password comparison error:', error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.REPL_ID || "evokeessence-secret",
    resave: true, // Changed to true to ensure session is saved on every request
    saveUninitialized: true, // Changed to true to prevent session expiration issues
    cookie: {
      // Ensure cookies work for all HTTP methods
      sameSite: 'lax',
      httpOnly: true,
      // Setting a longer session timeout for testing
      maxAge: 1000 * 60 * 60 * 24 // 24 hours
    },
    store: new MemoryStore({
      checkPeriod: 86400000,
    }),
  };

  if (app.get("env") === "production") {
    app.set("trust proxy", 1);
    sessionSettings.cookie = { 
      secure: true,
      sameSite: 'lax',
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 // 24 hours
    };
  }

  // Make sure to add this before any routes
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Add debugging middleware for authentication
  app.use((req, res, next) => {
    console.log(`Auth Debug - ${req.method} ${req.path} - authenticated: ${req.isAuthenticated()}, user: ${req.user ? req.user.id : 'none'}`);
    next();
  });

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log('Login attempt for username:', username);
        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.username, username))
          .limit(1);

        if (!user) {
          console.log('User not found:', username);
          return done(null, false, { message: "Incorrect username." });
        }

        const isMatch = await comparePasswords(password, user.password);
        if (!isMatch) {
          console.log('Password mismatch for user:', username);
          return done(null, false, { message: "Incorrect password." });
        }

        // Create sanitized user object with camelCase keys and balances
        const userData = {
          id: user.id,
          username: user.username,
          email: user.email || '',
          kycStatus: user.kyc_status,
          kyc_status: user.kyc_status,
          isAdmin: !!user.isAdmin,
          isEmployee: !!user.isEmployee,
          userGroup: user.userGroup || '',
          fullName: user.fullName || '',
          phoneNumber: user.phoneNumber || '',
          address: user.address || '',
          countryOfResidence: user.countryOfResidence || '',
          gender: user.gender || '',
          twoFactorEnabled: !!user.twoFactorEnabled,
          balances: [
            {
              amount: Number(user.balance) || 0,
              currency: user.balanceCurrency || 'EUR'
            }
          ]
        };

        console.log('User authenticated:', {
          id: userData.id,
          username: userData.username,
          isAdmin: userData.isAdmin,
          isEmployee: userData.isEmployee,
          userGroup: userData.userGroup
        });

        return done(null, userData);
      } catch (err) {
        console.error('Authentication error:', err);
        return done(err);
      }
    })
  );

  passport.serializeUser((user, done) => {
    console.log('Serializing user:', user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log('Deserializing user:', id);
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, id))
        .limit(1);

      if (!user) {
        console.log('User not found during deserialization:', id);
        return done(new Error('User not found'));
      }

      // Create sanitized user object with camelCase keys and balances
      const userData = {
        id: user.id,
        username: user.username,
        email: user.email || '',
        kycStatus: user.kyc_status,
        kyc_status: user.kyc_status,
        isAdmin: !!user.isAdmin,
        isEmployee: !!user.isEmployee,
        userGroup: user.userGroup || '',
        fullName: user.fullName || '',
        phoneNumber: user.phoneNumber || '',
        address: user.address || '',
        countryOfResidence: user.countryOfResidence || '',
        gender: user.gender || '',
        twoFactorEnabled: !!user.twoFactorEnabled,
        balances: [
          {
            amount: Number(user.balance) || 0,
            currency: user.balanceCurrency || 'EUR'
          }
        ]
      };

      console.log('User deserialized:', {
        id: userData.id,
        username: userData.username,
        isAdmin: userData.isAdmin,
        isEmployee: userData.isEmployee,
        userGroup: userData.userGroup
      });

      done(null, userData);
    } catch (err) {
      console.error('Deserialization error:', err);
      done(err);
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log('Login request received:', {
      body: { ...req.body, password: '[REDACTED]' }
    });

    passport.authenticate("local", (err: any, user: Express.User | false, info: any) => {
      if (err) {
        console.error('Login error:', err);
        return next(err);
      }
      if (!user) {
        console.log('Login failed:', info?.message);
        return res.status(400).json({ message: info?.message ?? "Login failed" });
      }

      req.login(user, (err) => {
        if (err) {
          console.error('Session creation error:', err);
          return next(err);
        }

        // Create sanitized user object with required fields for routing
        const userData = {
          id: user.id,
          username: user.username,
          email: user.email || '',
          isAdmin: !!user.isAdmin,
          isEmployee: !!user.isEmployee,
          userGroup: user.userGroup || '',
          kycStatus: user.kyc_status || 'pending',
          fullName: user.fullName || '',
          balances: user.balances // Added balances here
        };

        console.log('Login successful for user:', {
          id: userData.id,
          username: userData.username,
          isAdmin: userData.isAdmin,
          isEmployee: userData.isEmployee,
          userGroup: userData.userGroup
        });

        return res.json(userData);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  app.get("/api/user", (req, res) => {
    console.log('User info request:', {
      isAuthenticated: req.isAuthenticated(),
      user: req.user ? {
        id: req.user.id,
        username: req.user.username,
        isAdmin: req.user.isAdmin,
        isEmployee: req.user.isEmployee,
        userGroup: req.user.userGroup
      } : null
    });

    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Add Cache-Control headers to prevent caching
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('Pragma', 'no-cache');

    res.json(req.user);
  });
}